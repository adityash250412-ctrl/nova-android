package com.nova.assistant.parser

sealed class CommandResult {
    data class Success(
        val feedbackSpeech: String,
        val displayTitle: String,
        val detail: String = ""
    ) : CommandResult()

    data class Failure(
        val feedbackSpeech: String,
        val errorMessage: String
    ) : CommandResult()

    data class NeedsConfirmation(
        val prompt: String,
        val pendingCommand: NovaCommand
    ) : CommandResult()
}
