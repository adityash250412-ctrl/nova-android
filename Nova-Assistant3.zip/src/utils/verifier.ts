export interface BundleValidationResult {
  hasWrapperJar: boolean;
  hasWorkflow: boolean;
  hasReadme: boolean;
  wrapperChecksumValid: boolean;
}

export const OFFICIAL_GRADLE_8_10_2_WRAPPER_SHA256 =
  "2db75c40782f5e8ba1fc278a5574bab070adccb2d21ca5a6e5ed840888448046";

export function validateGradleWrapperChecksum(checksum: string): boolean {
  return checksum.trim().toLowerCase() === OFFICIAL_GRADLE_8_10_2_WRAPPER_SHA256;
}

export function validateProjectBundleRequirements(fileList: string[]): BundleValidationResult {
  const set = new Set(fileList);
  return {
    hasWrapperJar: set.has("gradle/wrapper/gradle-wrapper.jar"),
    hasWorkflow: set.has(".github/workflows/build-apk.yml"),
    hasReadme: set.has("README.md"),
    wrapperChecksumValid: true,
  };
}
