/**
 * Mirror of core NOVA pure logic algorithms for deterministic verification in Node/browser.
 */

export interface ParsedCommand {
  type: string;
  target?: string;
  query?: string;
  state?: boolean | null;
  rawInput: string;
}

export function parseVoiceCommand(rawText: string): ParsedCommand {
  let normalized = rawText.trim().toLowerCase();
  normalized = normalized.replace(/^(hey|hi|hello|ok|okay)?\s*nova[,:\s]*/, '').trim();

  if (!normalized) {
    return { type: 'UNKNOWN', rawInput: rawText };
  }

  // 1. Flashlight / Torch (English & Hindi/Hinglish)
  if (/\b(turn\s+on|enable|activate|switch\s+on|jalao|chalu\s+karo)\s+(the\s+)?(flashlight|torch)\b|\b(flashlight|torch)\s+(on|chalu|jalao|start)(\s+karo)?\b/.test(normalized)) {
    return { type: 'TOGGLE_FLASHLIGHT', state: true, rawInput: rawText };
  }
  if (/\b(turn\s+off|disable|deactivate|switch\s+off|bujhao|band\s+karo)\s+(the\s+)?(flashlight|torch)\b|\b(flashlight|torch)\s+(off|band|bujhao)(\s+karo)?\b/.test(normalized)) {
    return { type: 'TOGGLE_FLASHLIGHT', state: false, rawInput: rawText };
  }

  // 2. Volume
  if (/\b(volume|aawaz|awaaz|sound)\s+(kam|down|ghatao|dheemi)(\s+karo)?\b|\b(volume\s+down|lower\s+volume)\b/.test(normalized)) {
    return { type: 'ADJUST_VOLUME', target: 'DOWN', rawInput: rawText };
  }
  if (/\b(volume|aawaz|awaaz|sound)\s+(badhao|up|tez|increase)(\s+karo)?\b|\b(volume\s+up|raise\s+volume)\b/.test(normalized)) {
    return { type: 'ADJUST_VOLUME', target: 'UP', rawInput: rawText };
  }
  if (/\b(mute|silent|chup\s+karo)\b/.test(normalized)) {
    return { type: 'ADJUST_VOLUME', target: 'MUTE', rawInput: rawText };
  }

  // 3. Calls / Contacts
  const hindiCall = normalized.match(/^(.*?)\s+ko\s+(?:call|phone)\s+(?:karo|lagao|milao)$/);
  if (hindiCall) {
    return { type: 'CALL_CONTACT', target: hindiCall[1].trim(), rawInput: rawText };
  }
  const englishCall = normalized.match(/^(?:call|dial|phone)\s+(?:to\s+)?([a-z0-9\s._-]+)$/);
  if (englishCall && !englishCall[1].includes('setting')) {
    return { type: 'CALL_CONTACT', target: englishCall[1].trim(), rawInput: rawText };
  }

  // 4. Searches
  const hindiSearch = normalized.match(/^(google|youtube|web|chrome)\s+par\s+(.*?)\s+search\s+karo$/);
  if (hindiSearch) {
    return {
      type: hindiSearch[1] === 'youtube' ? 'SEARCH_YOUTUBE' : 'SEARCH_WEB',
      query: hindiSearch[2].trim(),
      rawInput: rawText,
    };
  }

  // 5. History & Help
  if (/\b(show\s+(my\s+)?(recent\s+)?(commands|history)|view\s+history|history\s+dikhao|purani\s+commands?)\b|^history$/.test(normalized)) {
    return { type: 'SHOW_HISTORY', rawInput: rawText };
  }
  if (/\b(what\s+can\s+you\s+do|help\s+me|help|kya\s+kar\s+sakte\s+ho|madad\s+karo)\b|^help$/.test(normalized)) {
    return { type: 'SHOW_HELP', rawInput: rawText };
  }

  // 6. Direct App Launch
  const appMatch = normalized.match(/^(?:open|launch|start|run)\s+(?:the\s+)?([a-z0-9\s._-]+)$/) ||
                   normalized.match(/^(?:the\s+)?([a-z0-9\s._-]+)\s+(?:kholo|open\s+karo|chalu\s+karo)$/);
  if (appMatch) {
    return { type: 'OPEN_APP', target: appMatch[1].trim(), rawInput: rawText };
  }

  // 7. Questions / AI
  if (/^(what|who|where|why|how|tell me|explain|calculate|kya|kaun|kahan|kaise)\b/.test(normalized)) {
    return { type: 'QUERY_AI', query: rawText, rawInput: rawText };
  }

  return { type: 'UNKNOWN', rawInput: rawText };
}

export const ALLOWED_ACTIONS = new Set([
  'OPEN_APP',
  'SEARCH_WEB',
  'SEARCH_YOUTUBE',
  'CALL_CONTACT',
  'SEND_WHATSAPP',
  'TOGGLE_FLASHLIGHT',
  'ADJUST_VOLUME',
  'OPEN_SETTINGS',
  'GET_BATTERY_STATUS',
  'CONVERSE',
  'SHOW_HISTORY',
  'SHOW_HELP'
]);

export function validateActionSafety(actionType: string): boolean {
  return ALLOWED_ACTIONS.has(actionType.trim().toUpperCase());
}

export function boundConversationHistory<T>(history: T[], maxTurns: number = 4): T[] {
  if (history.length <= maxTurns) return [...history];
  return history.slice(history.length - maxTurns);
}
