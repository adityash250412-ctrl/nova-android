import test from 'node:test';
import assert from 'node:assert/strict';
import {
  parseVoiceCommand,
  validateActionSafety,
  boundConversationHistory,
  ALLOWED_ACTIONS
} from './rules.ts';

test('CommandParser: parses English and Hindi flashlight commands', () => {
  const c1 = parseVoiceCommand('turn on flashlight');
  assert.equal(c1.type, 'TOGGLE_FLASHLIGHT');
  assert.equal(c1.state, true);

  const c2 = parseVoiceCommand('flashlight on karo');
  assert.equal(c2.type, 'TOGGLE_FLASHLIGHT');
  assert.equal(c2.state, true);

  const c3 = parseVoiceCommand('torch bujhao');
  assert.equal(c3.type, 'TOGGLE_FLASHLIGHT');
  assert.equal(c3.state, false);
});

test('CommandParser: parses volume adjustments', () => {
  const c1 = parseVoiceCommand('volume badhao');
  assert.equal(c1.type, 'ADJUST_VOLUME');
  assert.equal(c1.target, 'UP');

  const c2 = parseVoiceCommand('aawaz kam karo');
  assert.equal(c2.type, 'ADJUST_VOLUME');
  assert.equal(c2.target, 'DOWN');
});

test('CommandParser: parses contacts and calls in Hindi and English', () => {
  const c1 = parseVoiceCommand('call Mom');
  assert.equal(c1.type, 'CALL_CONTACT');
  assert.equal(c1.target, 'mom');

  const c2 = parseVoiceCommand('mummy ko call karo');
  assert.equal(c2.type, 'CALL_CONTACT');
  assert.equal(c2.target, 'mummy');
});

test('CommandParser: parses searches and app launching', () => {
  const c1 = parseVoiceCommand('YouTube par Minecraft Shorts search karo');
  assert.equal(c1.type, 'SEARCH_YOUTUBE');
  assert.equal(c1.query, 'minecraft shorts');

  const c2 = parseVoiceCommand('YouTube kholo');
  assert.equal(c2.type, 'OPEN_APP');
  assert.equal(c2.target, 'youtube');
});

test('CommandParser: parses history, help, questions and unknown', () => {
  assert.equal(parseVoiceCommand('show my recent commands').type, 'SHOW_HISTORY');
  assert.equal(parseVoiceCommand('history dikhao').type, 'SHOW_HISTORY');
  assert.equal(parseVoiceCommand('what can you do').type, 'SHOW_HELP');
  assert.equal(parseVoiceCommand('What is the capital of France?').type, 'QUERY_AI');
  assert.equal(parseVoiceCommand('random babble 12345').type, 'UNKNOWN');
});

test('Security allowlist: allows approved phone actions', () => {
  for (const action of ['OPEN_APP', 'SEARCH_WEB', 'SEARCH_YOUTUBE', 'CALL_CONTACT', 'TOGGLE_FLASHLIGHT', 'CONVERSE']) {
    assert.equal(validateActionSafety(action), true);
  }
});

test('Security allowlist: strictly blocks malicious or unauthorized intents', () => {
  assert.equal(validateActionSafety('RUN_SHELL'), false);
  assert.equal(validateActionSafety('EXECUTE_SCRIPT'), false);
  assert.equal(validateActionSafety('DELETE_FILES'), false);
  assert.equal(validateActionSafety('INSTALL_MALWARE'), false);
});

test('Conversation Context: limits history window to bounded size', () => {
  const turns = [
    { u: '1', a: '1' },
    { u: '2', a: '2' },
    { u: '3', a: '3' },
    { u: '4', a: '4' },
    { u: '5', a: '5' },
    { u: '6', a: '6' }
  ];
  const bounded = boundConversationHistory(turns, 4);
  assert.equal(bounded.length, 4);
  assert.equal(bounded[0].u, '3');
  assert.equal(bounded[3].u, '6');
});
