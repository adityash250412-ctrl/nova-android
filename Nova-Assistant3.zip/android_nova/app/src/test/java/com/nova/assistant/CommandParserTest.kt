package com.nova.assistant

import com.nova.assistant.parser.CommandParser
import com.nova.assistant.parser.NovaCommand
import com.nova.assistant.parser.SearchPlatform
import com.nova.assistant.parser.SettingTarget
import com.nova.assistant.parser.VolumeDirection
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class CommandParserTest {

    private lateinit var parser: CommandParser

    @Before
    fun setUp() {
        parser = CommandParser()
    }

    @Test
    fun testEmptyAndBlankInput() {
        val resultEmpty = parser.parse("")
        assertTrue(resultEmpty is NovaCommand.Unknown)

        val resultBlank = parser.parse("   ")
        assertTrue(resultBlank is NovaCommand.Unknown)
    }

    @Test
    fun testWakeWordStripping() {
        val cmd1 = parser.parse("Hey NOVA open YouTube")
        assertTrue(cmd1 is NovaCommand.OpenApp)
        assertEquals("youtube", (cmd1 as NovaCommand.OpenApp).appQuery)

        val cmd2 = parser.parse("ok nova torch on karo")
        assertTrue(cmd2 is NovaCommand.ToggleFlashlight)
        assertEquals(true, (cmd2 as NovaCommand.ToggleFlashlight).desiredState)
    }

    @Test
    fun testEnglishFlashlightCommands() {
        val onCmd = parser.parse("turn on flashlight")
        assertTrue(onCmd is NovaCommand.ToggleFlashlight)
        assertEquals(true, (onCmd as NovaCommand.ToggleFlashlight).desiredState)

        val offCmd = parser.parse("turn off the torch")
        assertTrue(offCmd is NovaCommand.ToggleFlashlight)
        assertEquals(false, (offCmd as NovaCommand.ToggleFlashlight).desiredState)

        val toggleCmd = parser.parse("toggle flashlight")
        assertTrue(toggleCmd is NovaCommand.ToggleFlashlight)
        assertEquals(null, (toggleCmd as NovaCommand.ToggleFlashlight).desiredState)
    }

    @Test
    fun testHindiFlashlightCommands() {
        val onHindi = parser.parse("flashlight on karo")
        assertTrue(onHindi is NovaCommand.ToggleFlashlight)
        assertEquals(true, (onHindi as NovaCommand.ToggleFlashlight).desiredState)

        val jalao = parser.parse("torch jalao")
        assertTrue(jalao is NovaCommand.ToggleFlashlight)
        assertEquals(true, (jalao as NovaCommand.ToggleFlashlight).desiredState)

        val bujhao = parser.parse("torch bujhao")
        assertTrue(bujhao is NovaCommand.ToggleFlashlight)
        assertEquals(false, (bujhao as NovaCommand.ToggleFlashlight).desiredState)
    }

    @Test
    fun testVolumeAdjustments() {
        val volUp = parser.parse("volume up")
        assertTrue(volUp is NovaCommand.AdjustVolume)
        assertEquals(VolumeDirection.UP, (volUp as NovaCommand.AdjustVolume).direction)

        val volDown = parser.parse("aawaz kam karo")
        assertTrue(volDown is NovaCommand.AdjustVolume)
        assertEquals(VolumeDirection.DOWN, (volDown as NovaCommand.AdjustVolume).direction)

        val mute = parser.parse("mute")
        assertTrue(mute is NovaCommand.AdjustVolume)
        assertEquals(VolumeDirection.MUTE, (mute as NovaCommand.AdjustVolume).direction)
    }

    @Test
    fun testCallsAndContacts() {
        val englishCall = parser.parse("call Mom")
        assertTrue(englishCall is NovaCommand.CallContact)
        assertEquals("mom", (englishCall as NovaCommand.CallContact).contactName)

        val hindiCall = parser.parse("mummy ko call karo")
        assertTrue(hindiCall is NovaCommand.CallContact)
        assertEquals("mummy", (hindiCall as NovaCommand.CallContact).contactName)
    }

    @Test
    fun testWebAndYouTubeSearches() {
        val googleSearch = parser.parse("search Google for weather today")
        assertTrue(googleSearch is NovaCommand.WebSearch)
        val ws = googleSearch as NovaCommand.WebSearch
        assertEquals("weather today", ws.query)
        assertEquals(SearchPlatform.GOOGLE, ws.platform)

        val ytHindi = parser.parse("YouTube par Minecraft Shorts search karo")
        assertTrue(ytHindi is NovaCommand.WebSearch)
        val yt = ytHindi as NovaCommand.WebSearch
        assertEquals("minecraft shorts", yt.query)
        assertEquals(SearchPlatform.YOUTUBE, yt.platform)
    }

    @Test
    fun testAppLaunching() {
        val launchYt = parser.parse("open YouTube")
        assertTrue(launchYt is NovaCommand.OpenApp)
        assertEquals("youtube", (launchYt as NovaCommand.OpenApp).appQuery)

        val launchHindi = parser.parse("instagram open karo")
        assertTrue(launchHindi is NovaCommand.OpenApp)
        assertEquals("instagram", (launchHindi as NovaCommand.OpenApp).appQuery)
    }

    @Test
    fun testSettingsCommands() {
        val wifi = parser.parse("open wifi settings")
        assertTrue(wifi is NovaCommand.OpenSettings)
        assertEquals(SettingTarget.Wifi, (wifi as NovaCommand.OpenSettings).target)

        val bt = parser.parse("bluetooth settings kholo")
        assertTrue(bt is NovaCommand.OpenSettings)
        assertEquals(SettingTarget.Bluetooth, (bt as NovaCommand.OpenSettings).target)
    }

    @Test
    fun testHistoryAndHelp() {
        val historyCmd = parser.parse("show my recent commands")
        assertTrue(historyCmd is NovaCommand.ShowHistory)

        val historyHindi = parser.parse("history dikhao")
        assertTrue(historyHindi is NovaCommand.ShowHistory)

        val helpCmd = parser.parse("what can you do")
        assertTrue(helpCmd is NovaCommand.ShowHelp)
    }

    @Test
    fun testAiQuestions() {
        val question = parser.parse("What is the speed of light?")
        assertTrue(question is NovaCommand.QueryAi)
        assertEquals("What is the speed of light?", (question as NovaCommand.QueryAi).question)
    }
}
