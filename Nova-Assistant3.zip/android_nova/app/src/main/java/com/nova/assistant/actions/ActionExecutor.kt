package com.nova.assistant.actions

import android.content.Context
import android.content.Intent
import com.nova.assistant.accessibility.NovaAccessibilityService
import com.nova.assistant.parser.AccessibilityActionType
import com.nova.assistant.parser.CommandResult
import com.nova.assistant.parser.NovaCommand

class ActionExecutor(
    private val context: Context,
    private val flashlightController: FlashlightController,
    private val appLauncher: AppLauncher,
    private val settingsLauncher: SettingsLauncher,
    private val contactCaller: ContactCaller,
    private val searchLauncher: SearchLauncher,
    private val volumeController: VolumeController
) {
    fun execute(command: NovaCommand): CommandResult {
        return when (command) {
            is NovaCommand.OpenApp -> {
                val result = appLauncher.launchApp(command.appQuery)
                result.fold(
                    onSuccess = { appLabel ->
                        CommandResult.Success(
                            feedbackSpeech = "Opening $appLabel.",
                            displayTitle = appLabel,
                            detail = "Launched: $appLabel"
                        )
                    },
                    onFailure = { error ->
                        CommandResult.Failure(
                            feedbackSpeech = "Sorry, ${command.appQuery} is not installed on your phone.",
                            errorMessage = error.localizedMessage ?: "Application launch failed."
                        )
                    }
                )
            }

            is NovaCommand.ToggleFlashlight -> {
                if (!flashlightController.isAvailable) {
                    return CommandResult.Failure(
                        feedbackSpeech = "Flashlight hardware is not available on this phone.",
                        errorMessage = "No camera flash hardware detected."
                    )
                }

                val toggleResult = if (command.desiredState != null) {
                    flashlightController.setTorchMode(command.desiredState)
                } else {
                    flashlightController.toggle()
                }

                toggleResult.fold(
                    onSuccess = { newState ->
                        val stateStr = if (newState) "on" else "off"
                        CommandResult.Success(
                            feedbackSpeech = "Flashlight turned $stateStr.",
                            displayTitle = "Flashlight",
                            detail = "Torch set to $stateStr"
                        )
                    },
                    onFailure = { error ->
                        CommandResult.Failure(
                            feedbackSpeech = "Could not change flashlight state.",
                            errorMessage = error.localizedMessage ?: "Unknown camera error."
                        )
                    }
                )
            }

            is NovaCommand.WebSearch -> {
                val result = searchLauncher.executeSearch(command.query, command.platform)
                result.fold(
                    onSuccess = { feedback ->
                        val platformName = if (command.platform == com.nova.assistant.parser.SearchPlatform.YOUTUBE) "YouTube" else "Google"
                        CommandResult.Success(
                            feedbackSpeech = feedback,
                            displayTitle = "$platformName Search",
                            detail = "Query: \"${command.query}\""
                        )
                    },
                    onFailure = { error ->
                        CommandResult.Failure(
                            feedbackSpeech = "Could not open search.",
                            errorMessage = error.localizedMessage ?: "Search intent failed."
                        )
                    }
                )
            }

            is NovaCommand.CallContact -> {
                val result = contactCaller.prepareCall(command.contactName)
                result.fold(
                    onSuccess = { (feedbackSpeech, detail) ->
                        CommandResult.Success(
                            feedbackSpeech = feedbackSpeech,
                            displayTitle = "Phone Dialer",
                            detail = detail
                        )
                    },
                    onFailure = { error ->
                        CommandResult.Failure(
                            feedbackSpeech = "Unable to access contacts.",
                            errorMessage = error.localizedMessage ?: "Contact lookup error."
                        )
                    }
                )
            }

            is NovaCommand.AdjustVolume -> {
                val result = volumeController.adjust(command.direction)
                result.fold(
                    onSuccess = { (feedbackSpeech, detail) ->
                        CommandResult.Success(
                            feedbackSpeech = feedbackSpeech,
                            displayTitle = "Volume",
                            detail = detail
                        )
                    },
                    onFailure = { error ->
                        CommandResult.Failure(
                            feedbackSpeech = "Could not adjust volume.",
                            errorMessage = error.localizedMessage ?: "Volume adjustment error."
                        )
                    }
                )
            }

            is NovaCommand.SendWhatsAppMessage -> {
                try {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        setPackage("com.whatsapp")
                        if (command.message.isNotBlank()) {
                            putExtra(Intent.EXTRA_TEXT, command.message)
                        }
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    if (intent.resolveActivity(context.packageManager) != null) {
                        context.startActivity(intent)
                        val speech = if (command.message.isNotBlank()) {
                            "Opening WhatsApp to draft: \"${command.message}\""
                        } else {
                            "Opening WhatsApp for ${command.recipient}."
                        }
                        CommandResult.Success(
                            feedbackSpeech = speech,
                            displayTitle = "WhatsApp",
                            detail = "Drafting message for ${command.recipient}"
                        )
                    } else {
                        // Fallback: check if WhatsApp is installed at all
                        val launchFallback = appLauncher.launchApp("whatsapp")
                        launchFallback.fold(
                            onSuccess = {
                                CommandResult.Success(
                                    feedbackSpeech = "Opening WhatsApp.",
                                    displayTitle = "WhatsApp",
                                    detail = "Launched WhatsApp"
                                )
                            },
                            onFailure = {
                                CommandResult.Failure(
                                    feedbackSpeech = "WhatsApp is not installed on this device.",
                                    errorMessage = "WhatsApp app not found"
                                )
                            }
                        )
                    }
                } catch (e: Exception) {
                    CommandResult.Failure(
                        feedbackSpeech = "Could not open WhatsApp.",
                        errorMessage = e.localizedMessage ?: "WhatsApp intent failed"
                    )
                }
            }

            is NovaCommand.OpenSettings -> {
                val result = settingsLauncher.open(command.target)
                result.fold(
                    onSuccess = {
                        CommandResult.Success(
                            feedbackSpeech = "Opening ${command.target.nameKey} settings.",
                            displayTitle = "${command.target.nameKey.replaceFirstChar { it.uppercase() }} Settings",
                            detail = "Dispatched settings intent: ${command.target.nameKey}"
                        )
                    },
                    onFailure = { error ->
                        CommandResult.Failure(
                            feedbackSpeech = "Could not open settings.",
                            errorMessage = error.localizedMessage ?: "Settings intent failed."
                        )
                    }
                )
            }

            is NovaCommand.SystemStatus -> {
                if (command.metric == "battery") {
                    val bm = context.getSystemService(Context.BATTERY_SERVICE) as? android.os.BatteryManager
                    val level = bm?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
                    if (level in 0..100) {
                        CommandResult.Success(
                            feedbackSpeech = "Your battery is at $level percent.",
                            displayTitle = "Battery Level",
                            detail = "$level%"
                        )
                    } else {
                        CommandResult.Failure(
                            feedbackSpeech = "Unable to read battery status right now.",
                            errorMessage = "Battery manager returned invalid capacity."
                        )
                    }
                } else {
                    CommandResult.Failure(
                        feedbackSpeech = "Status for ${command.metric} is not monitored.",
                        errorMessage = "Unsupported status metric."
                    )
                }
            }

            is NovaCommand.AccessibilityAction -> {
                val service = NovaAccessibilityService.instance
                if (service == null) {
                    return CommandResult.Failure(
                        feedbackSpeech = "Accessibility automation is not enabled. Please enable NOVA in Accessibility settings.",
                        errorMessage = "NovaAccessibilityService is not connected"
                    )
                }

                when (command.type) {
                    AccessibilityActionType.SCROLL_DOWN -> {
                        val success = service.scrollActiveWindow(forward = true)
                        if (success) {
                            CommandResult.Success("Scrolled down.", "Scroll Down", "Accessibility scroll action performed")
                        } else {
                            CommandResult.Failure("Unable to scroll this screen.", "Scroll failed")
                        }
                    }
                    AccessibilityActionType.SCROLL_UP -> {
                        val success = service.scrollActiveWindow(forward = false)
                        if (success) {
                            CommandResult.Success("Scrolled up.", "Scroll Up", "Accessibility scroll action performed")
                        } else {
                            CommandResult.Failure("Unable to scroll this screen.", "Scroll failed")
                        }
                    }
                    AccessibilityActionType.GO_BACK -> {
                        service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
                        CommandResult.Success("Going back.", "Back Action", "GLOBAL_ACTION_BACK performed")
                    }
                    AccessibilityActionType.GO_HOME -> {
                        service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)
                        CommandResult.Success("Going to home screen.", "Home Action", "GLOBAL_ACTION_HOME performed")
                    }
                    AccessibilityActionType.TAP_ELEMENT -> {
                        val success = service.clickNodeByText(command.parameter)
                        if (success) {
                            CommandResult.Success("Tapped ${command.parameter}.", "Tapped Element", "Clicked node: ${command.parameter}")
                        } else {
                            CommandResult.Failure("Could not find ${command.parameter} on screen.", "Element not found")
                        }
                    }
                    AccessibilityActionType.TYPE_TEXT -> {
                        val success = service.enterTextIntoFocusedField(command.parameter)
                        if (success) {
                            CommandResult.Success("Typed text.", "Entered Text", command.parameter)
                        } else {
                            CommandResult.Failure("No editable field focused.", "Typing failed")
                        }
                    }
                }
            }

            is NovaCommand.QueryAi -> {
                CommandResult.Success(
                    feedbackSpeech = command.question,
                    displayTitle = "NOVA AI",
                    detail = command.question
                )
            }

            is NovaCommand.ShowHistory -> {
                CommandResult.Success(
                    feedbackSpeech = "Opening your command history.",
                    displayTitle = "History",
                    detail = "Navigated to past voice command records"
                )
            }

            is NovaCommand.ShowHelp -> {
                CommandResult.Success(
                    feedbackSpeech = "I am NOVA. You can ask me to open apps like YouTube, turn on the flashlight, adjust volume, call contacts, search Google or YouTube, and converse using Gemini AI.",
                    displayTitle = "NOVA Capabilities",
                    detail = "Supported actions: apps, torch, volume, calls, web/YouTube search, and AI queries"
                )
            }

            is NovaCommand.Unknown -> {
                CommandResult.Failure(
                    feedbackSpeech = "I didn't recognize that command. Try 'YouTube kholo', 'turn on flashlight', or 'call Mom'.",
                    errorMessage = "Unrecognized command: \"${command.rawInput}\""
                )
            }
        }
    }
}
