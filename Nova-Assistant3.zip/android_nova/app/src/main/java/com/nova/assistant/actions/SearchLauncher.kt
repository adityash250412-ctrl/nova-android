package com.nova.assistant.actions

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.nova.assistant.parser.SearchPlatform
import java.net.URLEncoder

class SearchLauncher(private val context: Context) {

    fun executeSearch(query: String, platform: SearchPlatform): Result<String> {
        return try {
            when (platform) {
                SearchPlatform.GOOGLE -> {
                    // Try web search intent
                    val searchIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                        putExtra(SearchManager.QUERY, query)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    if (searchIntent.resolveActivity(context.packageManager) != null) {
                        context.startActivity(searchIntent)
                        Result.success("Searching Google for $query")
                    } else {
                        // Browser URL fallback
                        val encoded = URLEncoder.encode(query, "UTF-8")
                        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$encoded")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(browserIntent)
                        Result.success("Opened Google search for $query")
                    }
                }

                SearchPlatform.YOUTUBE -> {
                    // Try YouTube app search intent
                    val ytIntent = Intent(Intent.ACTION_SEARCH).apply {
                        setPackage("com.google.android.youtube")
                        putExtra("query", query)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    if (ytIntent.resolveActivity(context.packageManager) != null) {
                        context.startActivity(ytIntent)
                        Result.success("Searching YouTube for $query")
                    } else {
                        // Web fallback
                        val encoded = URLEncoder.encode(query, "UTF-8")
                        val webYtIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(webYtIntent)
                        Result.success("Opened YouTube search for $query")
                    }
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
