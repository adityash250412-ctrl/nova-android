package com.nova.assistant.wakeword

/**
 * WakeWordEngine Interface
 *
 * Real offline wake-word options for ₹0 budget on Android:
 *
 * 1. Vosk Android (100% Free, Apache 2.0 Open Source):
 *    - Dependency: `implementation("org.alphacephei:vosk-android:0.3.47")`
 *    - Model: Download small model `vosk-model-small-en-us-0.15` (40MB) or Hindi model into `assets/model-en`
 *    - Runs 100% offline, zero cost, no API keys, no monthly limits.
 *
 * 2. Continuous PCM Energy & Acoustic Pattern Spotter:
 *    - Integrated directly in NovaVoiceService.kt using 16kHz AudioRecord PCM frames.
 *    - Monitors vocal bursts to transition to SpeechRecognizer without proprietary binary blobs.
 *
 * 3. Picovoice Porcupine:
 *    - Proprietary with free tier (requires developer account and AccessKey).
 */
interface WakeWordEngine {
    val name: String
    val keyword: String
    val isReady: Boolean

    fun initialize(): Result<Unit>
    fun processAudioFrame(pcmData: ShortArray): Boolean
    fun release()
}

/**
 * KeywordEnergySpotter provides an integrated, zero-cost audio onset spotter
 * that processes 16kHz 16-bit PCM frames to detect user speech.
 */
class KeywordEnergySpotter(
    override val keyword: String = "Hey NOVA",
    private val thresholdRms: Double = 850.0
) : WakeWordEngine {

    override val name: String = "PCM Voice Onset Spotter"
    override var isReady: Boolean = true
        private set

    override fun initialize(): Result<Unit> {
        isReady = true
        return Result.success(Unit)
    }

    override fun processAudioFrame(pcmData: ShortArray): Boolean {
        if (pcmData.isEmpty()) return false
        var sum = 0.0
        for (sample in pcmData) {
            sum += sample * sample
        }
        val rms = Math.sqrt(sum / pcmData.size)
        return rms > thresholdRms
    }

    override fun release() {
        isReady = false
    }
}
