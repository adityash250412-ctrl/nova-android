package com.nova.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.assistant.ui.theme.NovaBorder
import com.nova.assistant.ui.theme.NovaCyan
import com.nova.assistant.ui.theme.NovaDeepNavy
import com.nova.assistant.ui.theme.NovaNeonBlue
import com.nova.assistant.ui.theme.NovaPurple
import com.nova.assistant.ui.theme.NovaSuccessGreen
import com.nova.assistant.ui.theme.NovaSurfaceDark
import com.nova.assistant.ui.theme.NovaSurfaceLight
import com.nova.assistant.ui.theme.NovaTextPrimary
import com.nova.assistant.ui.theme.NovaTextSecondary

@Composable
fun SettingsScreen(
    isAccessibilityEnabled: Boolean,
    isFlashlightOn: Boolean,
    onToggleFlashlight: () -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onTestTTS: () -> Unit,
    apiKey: String = "",
    onSaveApiKey: (String) -> Unit = {},
    listeningMode: String = "PUSH_TO_TALK",
    onSaveListeningMode: (String) -> Unit = {}
) {
    val scrollState = rememberScrollState()
    var geminiKeyInput by remember(apiKey) { mutableStateOf(apiKey) }
    var selectedMode by remember(listeningMode) { mutableStateOf(listeningMode) }
    val isKeySaved = apiKey.isNotBlank()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaDeepNavy)
            .verticalScroll(scrollState)
            .padding(20.dp)
    ) {
        // Header
        Text(
            text = "SETTINGS & PERMISSIONS",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = NovaTextPrimary
        )
        Text(
            text = "Configure voice models, device controls, and AI intent parsing",
            fontSize = 12.sp,
            color = NovaTextSecondary,
            modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
        )

        // Section 1: AI Provider & Gemini API Key
        SettingsSectionHeader(title = "AI NATURAL LANGUAGE PARSER", icon = Icons.Default.Psychology)
        
        SettingCard {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Google Gemini AI (gemini-2.5-flash)",
                            color = NovaTextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (isKeySaved) "Status: AI Active (Hindi, Hinglish & English)" else "Status: Offline Regex Only (Add Key Below)",
                            color = if (isKeySaved) NovaSuccessGreen else NovaCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    if (isKeySaved) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = NovaSuccessGreen,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = geminiKeyInput,
                    onValueChange = { geminiKeyInput = it },
                    label = { Text("Gemini API Key", fontSize = 12.sp) },
                    placeholder = { Text("Paste AI Studio API Key", fontSize = 12.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NovaCyan,
                        unfocusedBorderColor = NovaBorder,
                        focusedTextColor = NovaTextPrimary,
                        unfocusedTextColor = NovaTextPrimary
                    ),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { onSaveApiKey(geminiKeyInput) },
                        colors = ButtonDefaults.buttonColors(containerColor = NovaCyan),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Save API Key", color = NovaDeepNavy, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    if (isKeySaved) {
                        Button(
                            onClick = {
                                geminiKeyInput = ""
                                onSaveApiKey("")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NovaSurfaceLight),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Clear Key", color = NovaTextPrimary, fontSize = 11.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(NovaDeepNavy)
                        .padding(10.dp)
                ) {
                    Text(
                        text = "FREE TIER INFO: Get a free key with your Google account at aistudio.google.com/apikey (₹0 / 15 requests per minute). Key is securely stored locally on your device in private app storage and never committed to source code.",
                        color = NovaTextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 14.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Section 2: Voice Listening Strategy
        SettingsSectionHeader(title = "VOICE LISTENING STRATEGY", icon = Icons.Default.Hearing)
        
        SettingCard {
            Column {
                Text(
                    text = "Microphone Activation Mode",
                    color = NovaTextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Choose how NOVA listens for voice commands",
                    color = NovaTextSecondary,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // Option 1: Push to Talk
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            selectedMode = "PUSH_TO_TALK"
                            onSaveListeningMode("PUSH_TO_TALK")
                        }
                        .padding(vertical = 4.dp)
                ) {
                    RadioButton(
                        selected = selectedMode == "PUSH_TO_TALK",
                        onClick = {
                            selectedMode = "PUSH_TO_TALK"
                            onSaveListeningMode("PUSH_TO_TALK")
                        },
                        colors = RadioButtonDefaults.colors(selectedColor = NovaCyan)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text("Push-to-Talk (Recommended)", color = NovaTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text("Zero background battery drain. Tap Speak button or notification to command.", color = NovaTextSecondary, fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Option 2: Acoustic Onset
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            selectedMode = "ACOUSTIC_ENERGY"
                            onSaveListeningMode("ACOUSTIC_ENERGY")
                        }
                        .padding(vertical = 4.dp)
                ) {
                    RadioButton(
                        selected = selectedMode == "ACOUSTIC_ENERGY",
                        onClick = {
                            selectedMode = "ACOUSTIC_ENERGY"
                            onSaveListeningMode("ACOUSTIC_ENERGY")
                        },
                        colors = RadioButtonDefaults.colors(selectedColor = NovaCyan)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text("Acoustic Energy Spotter (Experimental)", color = NovaTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text("Continuous background audio recording. Higher battery usage; loud ambient sounds may trigger recognition.", color = NovaTextSecondary, fontSize = 11.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Section 3: Hardware Controls
        SettingsSectionHeader(title = "DEVICE & HARDWARE CONTROLS", icon = Icons.Default.FlashlightOn)
        
        SettingCard {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Flashlight / Torch",
                            color = NovaTextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Quick hardware test via CameraManager API",
                            color = NovaTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = isFlashlightOn,
                        onCheckedChange = { onToggleFlashlight() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NovaDeepNavy,
                            checkedTrackColor = NovaCyan,
                            uncheckedThumbColor = NovaTextSecondary,
                            uncheckedTrackColor = NovaSurfaceLight
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Section 4: Audio Feedback (TTS)
        SettingsSectionHeader(title = "VOICE SYNTHESIS (TTS)", icon = Icons.Default.VolumeUp)
        
        SettingCard {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Audio Feedback (TTS)",
                            color = NovaTextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Android TextToSpeech engine with natural voice synthesis",
                            color = NovaTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Button(
                        onClick = onTestTTS,
                        colors = ButtonDefaults.buttonColors(containerColor = NovaCyan),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Test Voice", color = NovaDeepNavy, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Section 5: Accessibility Service
        SettingsSectionHeader(title = "ACCESSIBILITY AUTOMATION", icon = Icons.Default.AccessibilityNew)
        
        SettingCard {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Nova Accessibility Automation",
                            color = NovaTextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (isAccessibilityEnabled) "Status: AUTHORIZED & ACTIVE" else "Status: NOT ENABLED (Optional)",
                            color = if (isAccessibilityEnabled) NovaSuccessGreen else NovaCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Button(
                        onClick = onOpenAccessibilitySettings,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isAccessibilityEnabled) NovaSurfaceLight else NovaCyan
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = if (isAccessibilityEnabled) "Config" else "Enable",
                            color = if (isAccessibilityEnabled) NovaTextPrimary else NovaDeepNavy,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(NovaDeepNavy)
                        .padding(10.dp)
                ) {
                    Text(
                        text = "SECURITY NOTICE: Android requires explicit user authorization in System Settings. NOVA will never silently inspect screens or bypass lock screen security.",
                        color = NovaTextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 14.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

@Composable
fun SettingsSectionHeader(title: String, icon: ImageVector) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(bottom = 8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = NovaCyan,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = title,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            color = NovaCyan
        )
    }
}

@Composable
fun SettingCard(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(NovaSurfaceDark)
            .border(1.dp, NovaBorder, RoundedCornerShape(12.dp))
            .padding(16.dp)
    ) {
        content()
    }
}
