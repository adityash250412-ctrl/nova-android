package com.nova.assistant.parser

import java.util.Locale

class CommandParser {

    /**
     * Parses raw user spoken or typed query into a structured NovaCommand.
     * Supports both English and Hindi/Hinglish phrasing completely offline.
     */
    fun parse(rawText: String): NovaCommand {
        // Strip common wake word prefixes if user speaks them together ("Hey NOVA open YouTube")
        var normalized = rawText.trim().lowercase(Locale.ROOT)
        normalized = normalized
            .replace(Regex("""^(hey|hi|hello|ok|okay)?\s*nova[,:\s]*"""), "")
            .trim()

        if (normalized.isEmpty()) {
            return NovaCommand.Unknown("")
        }

        // 1. Flashlight Commands (English + Hindi/Hinglish)
        // "turn on flashlight", "flashlight on karo", "torch on karo", "torch jalao", "flashlight on"
        val flashlightOnRegex = Regex("""\b(turn\s+on|enable|activate|switch\s+on|jalao|chalu\s+karo)\s+(the\s+)?(flashlight|torch)\b|\b(flashlight|torch)\s+(on|chalu|jalao|start)(\s+karo)?\b""")
        // "turn off flashlight", "flashlight band karo", "torch bujhao", "flashlight off"
        val flashlightOffRegex = Regex("""\b(turn\s+off|disable|deactivate|switch\s+off|bujhao|band\s+karo)\s+(the\s+)?(flashlight|torch)\b|\b(flashlight|torch)\s+(off|band|bujhao)(\s+karo)?\b""")
        val flashlightToggleRegex = Regex("""\b(toggle|switch)\s+(the\s+)?(flashlight|torch)\b|^(flashlight|torch)$""")

        if (flashlightOnRegex.containsMatchIn(normalized)) {
            return NovaCommand.ToggleFlashlight(desiredState = true)
        }
        if (flashlightOffRegex.containsMatchIn(normalized)) {
            return NovaCommand.ToggleFlashlight(desiredState = false)
        }
        if (flashlightToggleRegex.containsMatchIn(normalized)) {
            return NovaCommand.ToggleFlashlight(desiredState = null)
        }

        // 2. Volume Adjustments (English + Hindi/Hinglish)
        // "volume kam karo", "aawaz kam karo", "volume down", "lower volume", "decrease volume"
        val volumeDownRegex = Regex("""\b(volume|aawaz|awaaz|sound)\s+(kam|down|ghatao|dheemi)(\s+karo)?\b|\b(volume\s+down|lower\s+volume|decrease\s+volume)\b""")
        // "volume badhao", "aawaz badhao", "volume up", "raise volume", "increase volume"
        val volumeUpRegex = Regex("""\b(volume|aawaz|awaaz|sound)\s+(badhao|up|tez|increase)(\s+karo)?\b|\b(volume\s+up|raise\s+volume|increase\s+volume)\b""")
        val volumeMuteRegex = Regex("""\b(mute|silent|chup\s+karo)\b""")

        if (volumeDownRegex.containsMatchIn(normalized)) {
            return NovaCommand.AdjustVolume(VolumeDirection.DOWN)
        }
        if (volumeUpRegex.containsMatchIn(normalized)) {
            return NovaCommand.AdjustVolume(VolumeDirection.UP)
        }
        if (volumeMuteRegex.containsMatchIn(normalized)) {
            return NovaCommand.AdjustVolume(VolumeDirection.MUTE)
        }

        // 3. Calls & Contacts (English + Hindi/Hinglish)
        // "call mom", "mummy ko call karo", "call rahul", "rahul ko phone lagao"
        val hindiCallRegex = Regex("""^(.*?)\s+ko\s+(?:call|phone)\s+(?:karo|lagao|milao)$""")
        val hindiCallMatch = hindiCallRegex.find(normalized)
        if (hindiCallMatch != null) {
            val contactName = hindiCallMatch.groupValues[1].trim()
            if (contactName.isNotEmpty()) {
                return NovaCommand.CallContact(contactName)
            }
        }

        val englishCallRegex = Regex("""^(?:call|dial|phone)\s+(?:to\s+)?([a-z0-9\s._-]+)$""")
        val englishCallMatch = englishCallRegex.find(normalized)
        if (englishCallMatch != null) {
            val contactName = englishCallMatch.groupValues[1].trim()
            if (contactName.isNotEmpty() && !contactName.contains("setting")) {
                return NovaCommand.CallContact(contactName)
            }
        }

        // 4. Searches (Google & YouTube in English + Hindi/Hinglish)
        // "Google par Minecraft search karo", "YouTube par Free Fire search karo"
        val hindiSearchRegex = Regex("""^(google|youtube|web|chrome)\s+par\s+(.*?)\s+search\s+karo$""")
        val hindiSearchMatch = hindiSearchRegex.find(normalized)
        if (hindiSearchMatch != null) {
            val platformStr = hindiSearchMatch.groupValues[1].trim()
            val query = hindiSearchMatch.groupValues[2].trim()
            val platform = if (platformStr == "youtube") SearchPlatform.YOUTUBE else SearchPlatform.GOOGLE
            return NovaCommand.WebSearch(query, platform)
        }

        // "search Google for Minecraft shaders", "search YouTube for Free Fire tips", "search for weather"
        val englishSearchRegex = Regex("""^(?:search|look\s+up|find)\s+(?:(google|youtube|the\s+web)\s+(?:for\s+)?)?(.*?)$""")
        val englishSearchMatch = englishSearchRegex.find(normalized)
        if (englishSearchMatch != null) {
            val targetPlatform = englishSearchMatch.groupValues[1].trim()
            val query = englishSearchMatch.groupValues[2].trim()
            if (query.isNotEmpty() && (normalized.startsWith("search") || normalized.startsWith("look up") || normalized.startsWith("find"))) {
                val platform = if (targetPlatform == "youtube") SearchPlatform.YOUTUBE else SearchPlatform.GOOGLE
                // Clean leading "for " from query if present
                val cleanedQuery = query.removePrefix("for ").trim()
                if (cleanedQuery.isNotEmpty()) {
                    return NovaCommand.WebSearch(cleanedQuery, platform)
                }
            }
        }

        // 5. WhatsApp Message
        // "send WhatsApp message to Rohan", "Rohan ko WhatsApp karo"
        val whatsappMsgRegex = Regex("""^(?:send\s+whatsapp\s+(?:message\s+)?to\s+|(.*?)\s+ko\s+whatsapp\s+karo)(.*)$""")
        val waMatch = whatsappMsgRegex.find(normalized)
        if (waMatch != null) {
            val recipient = (waMatch.groupValues[1].ifEmpty { "someone" }).trim()
            val message = waMatch.groupValues[2].trim()
            return NovaCommand.SendWhatsAppMessage(recipient, message)
        }

        // 6. Settings Commands
        // "open wifi", "open bluetooth settings", "wifi settings kholo", etc.
        val settingsPrefixRegex = Regex("""\b(open|launch|show|go to)\s+(the\s+)?(.*?)(\s+settings|\s+options)?$|(.*?)\s+settings?\s+(?:kholo|dikhao)$""")
        val settingsMatch = settingsPrefixRegex.find(normalized)
        if (settingsMatch != null) {
            val target = (settingsMatch.groupValues[3].ifEmpty { settingsMatch.groupValues[5] }).trim()
            val isExplicitSettings = normalized.contains("setting") || normalized.startsWith("go to") || normalized.startsWith("show")
            
            val mappedSetting = when {
                target.contains("wifi") || target.contains("wi-fi") || target.contains("internet") || target.contains("network") -> SettingTarget.Wifi
                target.contains("bluetooth") || target.contains("bt") -> SettingTarget.Bluetooth
                target.contains("display") || target.contains("screen") || target.contains("brightness") -> SettingTarget.Display
                target.contains("sound") || target.contains("volume") || target.contains("audio") -> SettingTarget.Sound
                target.contains("battery") || target.contains("power") -> SettingTarget.Battery
                target.contains("apps") || target.contains("applications") || target.contains("app manager") -> SettingTarget.Apps
                target.contains("accessibility") || target.contains("talkback") -> SettingTarget.Accessibility
                target.contains("location") || target.contains("gps") -> SettingTarget.Location
                target.isEmpty() && isExplicitSettings -> SettingTarget.General
                else -> null
            }
            if (mappedSetting != null) {
                return NovaCommand.OpenSettings(mappedSetting)
            }
        }

        // 7. On-Screen Accessibility Gestures
        if (normalized.contains("scroll down") || normalized.contains("neeche scroll")) {
            return NovaCommand.AccessibilityAction(AccessibilityActionType.SCROLL_DOWN)
        }
        if (normalized.contains("scroll up") || normalized.contains("upar scroll")) {
            return NovaCommand.AccessibilityAction(AccessibilityActionType.SCROLL_UP)
        }
        if (normalized == "go back" || normalized == "back" || normalized == "peeche jao") {
            return NovaCommand.AccessibilityAction(AccessibilityActionType.GO_BACK)
        }
        if (normalized == "go home" || normalized == "home" || normalized == "home screen jao") {
            return NovaCommand.AccessibilityAction(AccessibilityActionType.GO_HOME)
        }

        // 8. Application Launch Commands (English + Hindi/Hinglish)
        // "open youtube", "youtube kholo", "launch instagram", "instagram open karo"
        val hindiAppLaunch = Regex("""^(?:the\s+)?([a-z0-9\s._-]+)\s+(?:kholo|open\s+karo|chalu\s+karo)$""")
        val hindiAppMatch = hindiAppLaunch.find(normalized)
        if (hindiAppMatch != null) {
            val appQuery = hindiAppMatch.groupValues[1].trim()
            if (appQuery.isNotEmpty()) {
                return NovaCommand.OpenApp(appQuery)
            }
        }

        val appLaunchRegex = Regex("""^(?:open|launch|start|run|play)\s+(?:the\s+)?([a-z0-9\s._-]+)$""")
        val appMatch = appLaunchRegex.find(normalized)
        if (appMatch != null) {
            val appQuery = appMatch.groupValues[1].trim()
            if (appQuery.isNotEmpty() && !appQuery.contains("settings")) {
                return NovaCommand.OpenApp(appQuery)
            }
        }

        // Popular direct app names
        val popularApps = setOf("youtube", "instagram", "camera", "calculator", "calendar", "chrome", "maps", "spotify", "whatsapp", "clock", "gallery", "phone", "messages")
        if (popularApps.contains(normalized)) {
            return NovaCommand.OpenApp(normalized)
        }

        // 9. History & Help Commands (English + Hindi/Hinglish)
        val historyRegex = Regex("""\b(show\s+(my\s+)?(recent\s+)?(commands|history)|view\s+history|history\s+dikhao|purani\s+commands?)\b|^history$""")
        if (historyRegex.containsMatchIn(normalized)) {
            return NovaCommand.ShowHistory
        }

        val helpRegex = Regex("""\b(what\s+can\s+you\s+do|help\s+me|help|kya\s+kar\s+sakte\s+ho|madad\s+karo)\b|^help$""")
        if (helpRegex.containsMatchIn(normalized)) {
            return NovaCommand.ShowHelp
        }

        // 10. Battery / System Status
        if (normalized.contains("battery level") || normalized.contains("how much battery") || normalized.contains("battery kitni hai")) {
            return NovaCommand.SystemStatus("battery")
        }

        // 11. Questions / AI
        val questionPrefixes = listOf("what", "who", "where", "why", "how", "tell me", "explain", "calculate", "kya", "kaun", "kahan", "kaise")
        if (questionPrefixes.any { normalized.startsWith(it) }) {
            return NovaCommand.QueryAi(rawText)
        }

        return NovaCommand.Unknown(rawText)
    }
}
