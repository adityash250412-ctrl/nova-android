package com.nova.assistant

import android.app.Application
import android.content.Context
import com.nova.assistant.actions.ActionExecutor
import com.nova.assistant.actions.AppLauncher
import com.nova.assistant.actions.ContactCaller
import com.nova.assistant.actions.FlashlightController
import com.nova.assistant.actions.SearchLauncher
import com.nova.assistant.actions.SettingsLauncher
import com.nova.assistant.actions.VolumeController
import com.nova.assistant.ai.GeminiProvider
import com.nova.assistant.ai.NovaActionDispatcher
import com.nova.assistant.history.CommandHistoryRepository
import com.nova.assistant.parser.CommandParser
import com.nova.assistant.permissions.PermissionManager
import com.nova.assistant.tts.NovaTTS

class NovaApplication : Application() {

    lateinit var flashlightController: FlashlightController
        private set

    lateinit var appLauncher: AppLauncher
        private set

    lateinit var settingsLauncher: SettingsLauncher
        private set

    lateinit var contactCaller: ContactCaller
        private set

    lateinit var searchLauncher: SearchLauncher
        private set

    lateinit var volumeController: VolumeController
        private set

    lateinit var actionExecutor: ActionExecutor
        private set

    lateinit var commandParser: CommandParser
        private set

    lateinit var geminiProvider: GeminiProvider
        private set

    lateinit var actionDispatcher: NovaActionDispatcher
        private set

    lateinit var tts: NovaTTS
        private set

    lateinit var historyRepository: CommandHistoryRepository
        private set

    lateinit var permissionManager: PermissionManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        permissionManager = PermissionManager(this)
        flashlightController = FlashlightController(this)
        appLauncher = AppLauncher(this)
        settingsLauncher = SettingsLauncher(this)
        contactCaller = ContactCaller(this)
        searchLauncher = SearchLauncher(this)
        volumeController = VolumeController(this)

        actionExecutor = ActionExecutor(
            this,
            flashlightController,
            appLauncher,
            settingsLauncher,
            contactCaller,
            searchLauncher,
            volumeController
        )

        commandParser = CommandParser()

        // Load persisted Gemini API Key securely from private app preferences
        val prefs = getSharedPreferences("nova_settings_prefs", Context.MODE_PRIVATE)
        val savedKey = prefs.getString("gemini_api_key", "") ?: ""
        geminiProvider = GeminiProvider(savedKey)
        actionDispatcher = NovaActionDispatcher()

        tts = NovaTTS(this)
        historyRepository = CommandHistoryRepository(this)
    }

    fun setGeminiApiKey(key: String) {
        val trimmed = key.trim()
        val prefs = getSharedPreferences("nova_settings_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("gemini_api_key", trimmed).apply()
        geminiProvider.updateApiKey(trimmed)
    }

    fun getGeminiApiKey(): String {
        val prefs = getSharedPreferences("nova_settings_prefs", Context.MODE_PRIVATE)
        return prefs.getString("gemini_api_key", "") ?: ""
    }

    fun getListeningMode(): String {
        val prefs = getSharedPreferences("nova_settings_prefs", Context.MODE_PRIVATE)
        return prefs.getString("listening_mode", "PUSH_TO_TALK") ?: "PUSH_TO_TALK"
    }

    fun setListeningMode(mode: String) {
        val prefs = getSharedPreferences("nova_settings_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("listening_mode", mode).apply()
    }

    override fun onTerminate() {
        super.onTerminate()
        tts.shutdown()
        flashlightController.release()
    }

    companion object {
        lateinit var instance: NovaApplication
            private set
    }
}
