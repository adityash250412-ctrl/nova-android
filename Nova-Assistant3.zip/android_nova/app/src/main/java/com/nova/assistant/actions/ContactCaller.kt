package com.nova.assistant.actions

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

class ContactCaller(private val context: Context) {

    fun prepareCall(contactNameQuery: String): Result<Pair<String, String>> {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED

        // If no contact permission granted yet, return fallback dialer instruction
        if (!hasPermission) {
            val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(dialIntent)
            return Result.success(
                Pair(
                    "Contacts permission not granted. Opened dialer for '$contactNameQuery'.",
                    "Tap phone to dial manually or grant contacts permission in Settings."
                )
            )
        }

        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%$contactNameQuery%")

        try {
            val cursor = context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection,
                selection,
                selectionArgs,
                null
            )

            cursor?.use {
                if (it.moveToFirst()) {
                    val nameIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                    val numberIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    val matchedName = it.getString(nameIndex)
                    val matchedNumber = it.getString(numberIndex)

                    // Safe confirmation flow: Open dialer with number pre-filled
                    val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$matchedNumber")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(dialIntent)

                    return Result.success(
                        Pair(
                            "Found $matchedName. Opening dialer.",
                            "Dialing: $matchedName ($matchedNumber)"
                        )
                    )
                }
            }
        } catch (e: Exception) {
            return Result.failure(e)
        }

        // Fallback: contact not found in phonebook, open dialer
        val dialIntent = Intent(Intent.ACTION_DIAL).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(dialIntent)
        return Result.success(
            Pair(
                "Could not find '$contactNameQuery' in contacts. Opened phone dialer.",
                "No contact match for: $contactNameQuery"
            )
        )
    }
}
