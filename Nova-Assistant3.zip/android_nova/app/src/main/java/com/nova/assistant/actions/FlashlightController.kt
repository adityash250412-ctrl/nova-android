package com.nova.assistant.actions

import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.util.Log

class FlashlightController(private val context: Context) {

    private val tag = "FlashlightController"
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    private var cameraId: String? = null
    var isTorchOn: Boolean = false
        private set

    init {
        detectFlashlight()
        registerTorchCallback()
    }

    private fun detectFlashlight() {
        val hasFlash = context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)
        if (!hasFlash || cameraManager == null) {
            Log.w(tag, "Device does not report camera flash feature")
            return
        }

        try {
            for (id in cameraManager.cameraIdList) {
                val characteristics = cameraManager.getCameraCharacteristics(id)
                val flashAvailable = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) ?: false
                val facing = characteristics.get(CameraCharacteristics.LENS_FACING)
                if (flashAvailable && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    cameraId = id
                    break
                }
            }
            if (cameraId == null && cameraManager.cameraIdList.isNotEmpty()) {
                cameraId = cameraManager.cameraIdList[0]
            }
        } catch (e: Exception) {
            Log.e(tag, "Failed to inspect camera characteristics", e)
        }
    }

    private fun registerTorchCallback() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && cameraManager != null) {
            cameraManager.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(camId: String, enabled: Boolean) {
                    super.onTorchModeChanged(camId, enabled)
                    if (camId == cameraId) {
                        isTorchOn = enabled
                    }
                }
            }, null)
        }
    }

    val isAvailable: Boolean
        get() = isSupported()

    fun isSupported(): Boolean {
        return context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH) && cameraId != null
    }

    fun setTorchMode(enable: Boolean): Result<Boolean> = setTorch(enable)

    fun setTorch(enable: Boolean): Result<Boolean> {
        val id = cameraId ?: return Result.failure(IllegalStateException("No flashlight hardware detected on this device."))
        val manager = cameraManager ?: return Result.failure(IllegalStateException("Camera service unavailable."))

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                manager.setTorchMode(id, enable)
                isTorchOn = enable
                Result.success(enable)
            } else {
                Result.failure(UnsupportedOperationException("Torch mode requires Android 6.0+ (API 23)"))
            }
        } catch (e: CameraAccessException) {
            Result.failure(e)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun toggle(): Result<Boolean> {
        return setTorch(!isTorchOn)
    }

    fun release() {
        if (isTorchOn) {
            setTorch(false)
        }
    }
}
