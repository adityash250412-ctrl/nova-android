package com.nova.assistant

import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.nova.assistant.accessibility.AccessibilityHelper
import com.nova.assistant.parser.CommandResult
import com.nova.assistant.service.NovaVoiceService
import com.nova.assistant.ui.screens.HistoryScreen
import com.nova.assistant.ui.screens.HomeScreen
import com.nova.assistant.ui.screens.SettingsScreen
import com.nova.assistant.ui.theme.NOVATheme
import com.nova.assistant.ui.theme.NovaCyan
import com.nova.assistant.ui.theme.NovaDeepNavy
import com.nova.assistant.ui.theme.NovaSurfaceDark
import com.nova.assistant.ui.theme.NovaTextPrimary
import com.nova.assistant.ui.theme.NovaTextSecondary

class MainActivity : ComponentActivity() {

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val recordAudioGranted = permissions[android.Manifest.permission.RECORD_AUDIO] ?: false
        if (recordAudioGranted) {
            Toast.makeText(this, "Microphone permission granted!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Microphone permission is required for voice commands.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestRequiredPermissions()

        setContent {
            NOVATheme {
                NovaAppRoot()
            }
        }
    }

    private fun requestRequiredPermissions() {
        val app = NovaApplication.instance
        val missing = app.permissionManager.getMissingRequiredPermissions()
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun checkMicPermission(): Boolean {
        return NovaApplication.instance.permissionManager.hasRecordAudioPermission()
    }

    private fun startNova() {
        if (!checkMicPermission()) {
            requestRequiredPermissions()
            return
        }
        NovaVoiceService.startService(this)
    }

    private fun stopNova() {
        NovaVoiceService.stopService(this)
    }

    @Composable
    fun NovaAppRoot() {
        var currentTab by remember { mutableIntStateOf(0) }
        val app = NovaApplication.instance

        val serviceState by NovaVoiceService.serviceState.collectAsState()
        val statusMessage by NovaVoiceService.statusMessage.collectAsState()
        val lastCommand by NovaVoiceService.lastCommand.collectAsState()
        val lastResult by NovaVoiceService.lastResult.collectAsState()
        val historyList by app.historyRepository.history.collectAsState()

        val isAccessibilityEnabled = AccessibilityHelper.isAccessibilityServiceEnabled(this)
        var hasMicPermission by remember { mutableStateOf(checkMicPermission()) }

        val apiKey = app.getGeminiApiKey()
        var currentListeningMode by remember { mutableStateOf(app.getListeningMode()) }

        // Navigate to History tab if user explicitly asked "Show my recent commands"
        LaunchedEffect(lastResult) {
            if (lastResult?.displayTitle == "History") {
                currentTab = 1
            }
        }

        Scaffold(
            bottomBar = {
                NavigationBar(
                    containerColor = NovaSurfaceDark,
                    contentColor = NovaTextPrimary
                ) {
                    NavigationBarItem(
                        selected = currentTab == 0,
                        onClick = { currentTab = 0 },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                        label = { Text("Assistant") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NovaCyan,
                            selectedTextColor = NovaCyan,
                            unselectedIconColor = NovaTextSecondary,
                            unselectedTextColor = NovaTextSecondary,
                            indicatorColor = NovaDeepNavy
                        )
                    )
                    NavigationBarItem(
                        selected = currentTab == 1,
                        onClick = { currentTab = 1 },
                        icon = { Icon(Icons.Default.History, contentDescription = "History") },
                        label = { Text("History") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NovaCyan,
                            selectedTextColor = NovaCyan,
                            unselectedIconColor = NovaTextSecondary,
                            unselectedTextColor = NovaTextSecondary,
                            indicatorColor = NovaDeepNavy
                        )
                    )
                    NavigationBarItem(
                        selected = currentTab == 2,
                        onClick = { currentTab = 2 },
                        icon = {
                            Icon(
                                Icons.Default.Settings,
                                contentDescription = "Settings"
                            )
                        },
                        label = { Text("Settings") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NovaCyan,
                            selectedTextColor = NovaCyan,
                            unselectedIconColor = NovaTextSecondary,
                            unselectedTextColor = NovaTextSecondary,
                            indicatorColor = NovaDeepNavy
                        )
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(NovaDeepNavy)
            ) {
                when (currentTab) {
                    0 -> HomeScreen(
                        isServiceRunning = NovaVoiceService.isRunning,
                        phase = serviceState,
                        statusExplanation = statusMessage,
                        hasMicPermission = hasMicPermission,
                        lastCommand = lastCommand,
                        lastResult = lastResult,
                        onStartNova = {
                            hasMicPermission = checkMicPermission()
                            startNova()
                        },
                        onStopNova = { stopNova() },
                        onTriggerListen = {
                            hasMicPermission = checkMicPermission()
                            if (!hasMicPermission) {
                                requestRequiredPermissions()
                            } else {
                                if (!NovaVoiceService.isRunning) {
                                    startNova()
                                }
                                NovaVoiceService.triggerListening(this@MainActivity)
                            }
                        },
                        onStopSpeaking = {
                            NovaVoiceService.stopSpeaking(this@MainActivity)
                        },
                        onRequestMicPermission = { requestRequiredPermissions() },
                        onNavigateToSettings = { currentTab = 2 }
                    )
                    1 -> HistoryScreen(
                        historyItems = historyList,
                        onClearHistory = { app.historyRepository.clearHistory() }
                    )
                    2 -> SettingsScreen(
                        isAccessibilityEnabled = isAccessibilityEnabled,
                        isFlashlightOn = app.flashlightController.isTorchOn,
                        onToggleFlashlight = {
                            val res = app.flashlightController.toggle()
                            res.onFailure {
                                Toast.makeText(this@MainActivity, it.message, Toast.LENGTH_SHORT).show()
                            }
                        },
                        onOpenAccessibilitySettings = {
                            AccessibilityHelper.openAccessibilitySettings(this@MainActivity)
                        },
                        onTestTTS = {
                            app.tts.speak("NOVA voice synthesis is operational.")
                        },
                        apiKey = apiKey,
                        onSaveApiKey = { newKey ->
                            app.setGeminiApiKey(newKey)
                            Toast.makeText(this@MainActivity, "Gemini API Key saved!", Toast.LENGTH_SHORT).show()
                        },
                        listeningMode = currentListeningMode,
                        onSaveListeningMode = { mode ->
                            currentListeningMode = mode
                            app.setListeningMode(mode)
                            Toast.makeText(this@MainActivity, "Listening mode set to: $mode", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }
}
