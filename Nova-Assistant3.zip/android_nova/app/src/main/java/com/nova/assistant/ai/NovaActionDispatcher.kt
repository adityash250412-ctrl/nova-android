package com.nova.assistant.ai

import com.nova.assistant.parser.NovaCommand
import com.nova.assistant.parser.SearchPlatform
import com.nova.assistant.parser.SettingTarget
import com.nova.assistant.parser.VolumeDirection
import org.json.JSONObject

/**
 * NovaActionDispatcher enforces a STRICT SECURITY ALLOWLIST on all AI outputs.
 * It prevents execution of arbitrary code, shell commands, or unapproved actions,
 * and maps valid structured JSON into strongly typed NovaCommand instances.
 */
class NovaActionDispatcher {

    private val allowedActions = setOf(
        "OPEN_APP",
        "SEARCH_WEB",
        "SEARCH_YOUTUBE",
        "CALL_CONTACT",
        "SEND_WHATSAPP",
        "TOGGLE_FLASHLIGHT",
        "ADJUST_VOLUME",
        "OPEN_SETTINGS",
        "GET_BATTERY_STATUS",
        "CONVERSE"
    )

    fun validateAndMap(requestJson: String): Result<NovaCommand> {
        return try {
            val json = JSONObject(requestJson)
            val action = json.optString("actionType", "CONVERSE").trim().uppercase()

            if (!allowedActions.contains(action)) {
                return Result.failure(
                    SecurityException("Blocked unauthorized AI action '$action'. Only allowlisted phone actions are permitted.")
                )
            }

            val command = when (action) {
                "OPEN_APP" -> {
                    val appName = json.optString("appName", json.optString("appQuery", "")).trim()
                    if (appName.isEmpty()) {
                        return Result.failure(IllegalArgumentException("Missing appName for OPEN_APP"))
                    }
                    NovaCommand.OpenApp(appName)
                }

                "SEARCH_WEB" -> {
                    val query = json.optString("searchQuery", json.optString("query", "")).trim()
                    if (query.isEmpty()) {
                        return Result.failure(IllegalArgumentException("Missing searchQuery for SEARCH_WEB"))
                    }
                    NovaCommand.WebSearch(query, SearchPlatform.GOOGLE)
                }

                "SEARCH_YOUTUBE" -> {
                    val query = json.optString("searchQuery", json.optString("query", "")).trim()
                    if (query.isEmpty()) {
                        return Result.failure(IllegalArgumentException("Missing searchQuery for SEARCH_YOUTUBE"))
                    }
                    NovaCommand.WebSearch(query, SearchPlatform.YOUTUBE)
                }

                "CALL_CONTACT" -> {
                    val contact = json.optString("contactName", json.optString("recipient", "someone")).trim()
                    NovaCommand.CallContact(contact)
                }

                "SEND_WHATSAPP" -> {
                    val recipient = json.optString("contactName", json.optString("recipient", "someone")).trim()
                    val message = json.optString("messageText", json.optString("message", "")).trim()
                    NovaCommand.SendWhatsAppMessage(recipient, message)
                }

                "TOGGLE_FLASHLIGHT" -> {
                    val desired = if (json.has("state")) json.optBoolean("state") else null
                    NovaCommand.ToggleFlashlight(desired)
                }

                "ADJUST_VOLUME" -> {
                    val dir = when (json.optString("volumeDirection", json.optString("direction", "up")).lowercase()) {
                        "down", "kam", "ghatao", "low" -> VolumeDirection.DOWN
                        "mute", "silent", "chup" -> VolumeDirection.MUTE
                        else -> VolumeDirection.UP
                    }
                    NovaCommand.AdjustVolume(dir)
                }

                "OPEN_SETTINGS" -> {
                    val target = when (json.optString("settingTarget", json.optString("target", "general")).lowercase()) {
                        "wifi", "wi-fi", "internet" -> SettingTarget.Wifi
                        "bluetooth", "bt" -> SettingTarget.Bluetooth
                        "display", "screen", "brightness" -> SettingTarget.Display
                        "sound", "volume", "audio" -> SettingTarget.Sound
                        "battery", "power" -> SettingTarget.Battery
                        "apps", "applications" -> SettingTarget.Apps
                        "accessibility" -> SettingTarget.Accessibility
                        "location", "gps" -> SettingTarget.Location
                        else -> SettingTarget.General
                    }
                    NovaCommand.OpenSettings(target)
                }

                "GET_BATTERY_STATUS" -> NovaCommand.SystemStatus("battery")

                "CONVERSE" -> {
                    val speech = json.optString("speechResponse", "I am NOVA, your voice assistant.")
                    NovaCommand.QueryAi(speech)
                }

                else -> NovaCommand.Unknown(requestJson)
            }

            Result.success(command)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
