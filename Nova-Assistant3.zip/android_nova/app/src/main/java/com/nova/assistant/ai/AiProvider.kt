package com.nova.assistant.ai

import com.nova.assistant.history.ConversationTurn

/**
 * Modular AI Provider Interface.
 *
 * Security Guidelines:
 * 1. NEVER embed private API keys in BuildConfig or strings.xml—APKs can be decompiled in seconds.
 * 2. User-provided keys are securely stored locally in private SharedPreferences on device.
 * 3. In enterprise/production architectures, requests route through a verified backend proxy.
 */
interface AiProvider {
    val providerName: String
    val isConfigured: Boolean

    suspend fun generateActionPlan(
        userPrompt: String,
        conversationHistory: List<ConversationTurn> = emptyList()
    ): Result<String>
}
