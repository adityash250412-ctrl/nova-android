package com.nova.assistant.wakeword

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.nova.assistant.MainActivity
import com.nova.assistant.R

/**
 * WakeWordService manages continuous background microphone monitoring.
 *
 * Android OS Restrictions & Architecture:
 * 1. Android 14+ (API 34) requires FOREGROUND_SERVICE_TYPE_MICROPHONE in manifest and startForeground().
 * 2. Background audio recording without a visible foreground notification is blocked by Android security.
 * 3. Doze Mode / Battery Optimization: The app must request exemption via
 *    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS to avoid CPU sleep while screen is off.
 * 4. Lock Screen: Launching an activity from the background on Android 10+ requires high-priority
 *    notification fullScreenIntent or user prompt.
 */
class WakeWordService : Service() {

    private val tag = "WakeWordService"
    private val channelId = "nova_wakeword_channel"
    private val notificationId = 1001

    private var audioRecord: AudioRecord? = null
    private var isRecording = false
    private var recordingThread: Thread? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildForegroundNotification()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val serviceType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_NONE
            }
            startForeground(notificationId, notification, serviceType)
        } else {
            startForeground(notificationId, notification)
        }

        acquireWakeLock()
        startAudioCapture()

        return START_STICKY
    }

    private fun acquireWakeLock() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        wakeLock = powerManager?.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "nova:wakeword_wakelock"
        )?.apply {
            setReferenceCounted(false)
            acquire(10 * 60 * 1000L) // 10 minutes timeout safety
        }
    }

    private fun startAudioCapture() {
        if (isRecording) return

        val sampleRate = 16000
        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val audioFormat = AudioFormat.ENCODING_PCM_16BIT
        val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)

        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                sampleRate,
                channelConfig,
                audioFormat,
                bufferSize
            )

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                Log.e(tag, "AudioRecord could not initialize")
                stopSelf()
                return
            }

            audioRecord?.startRecording()
            isRecording = true

            recordingThread = Thread {
                val buffer = ShortArray(512)
                while (isRecording && !Thread.currentThread().isInterrupted) {
                    val readCount = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (readCount > 0) {
                        // Pass buffer to WakeWordEngine (e.g. Porcupine / Vosk)
                        // If detected: broadcast Intent to launch Assistant UI
                    }
                }
            }
            recordingThread?.start()
            Log.i(tag, "WakeWord audio listening started")

        } catch (e: SecurityException) {
            Log.e(tag, "Missing RECORD_AUDIO permission for WakeWordService", e)
            stopSelf()
        } catch (e: Exception) {
            Log.e(tag, "Failed to start AudioRecord", e)
            stopSelf()
        }
    }

    private fun buildForegroundNotification(): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.wake_word_notification_title))
            .setContentText(getString(R.string.wake_word_notification_desc))
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "NOVA Wake Word Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows continuous notification when NOVA is listening for wake words"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isRecording = false
        recordingThread?.interrupt()
        recordingThread = null

        try {
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
        } catch (e: Exception) {
            Log.e(tag, "Error releasing AudioRecord", e)
        }

        wakeLock?.let {
            if (it.isHeld) it.release()
        }
        wakeLock = null

        Log.i(tag, "WakeWordService stopped")
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
