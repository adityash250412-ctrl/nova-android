package com.nova.assistant.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = NovaCyan,
    secondary = NovaPurple,
    tertiary = NovaNeonBlue,
    background = NovaDeepNavy,
    surface = NovaSurfaceDark,
    onPrimary = NovaDeepNavy,
    onSecondary = NovaTextPrimary,
    onBackground = NovaTextPrimary,
    onSurface = NovaTextPrimary
)

@Composable
fun NOVATheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
