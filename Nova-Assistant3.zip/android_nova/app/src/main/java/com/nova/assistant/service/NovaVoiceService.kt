package com.nova.assistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.app.NotificationCompat
import com.nova.assistant.MainActivity
import com.nova.assistant.NovaApplication
import com.nova.assistant.R
import com.nova.assistant.parser.CommandResult
import com.nova.assistant.parser.NovaCommand
import com.nova.assistant.wakeword.KeywordEnergySpotter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

enum class AssistantPhase {
    STOPPED,
    IDLE,
    LISTENING,
    PROCESSING,
    SPEAKING,
    EXECUTING_ACTION,
    ERROR
}

/**
 * NovaVoiceService is the central Android Foreground Service:
 * - Single source of truth for voice assistant lifecycle
 * - Enforces single microphone session (no AudioRecord / SpeechRecognizer contention)
 * - Supports Push-to-Talk (Default, 0 idle battery drain) and Continuous Acoustic Spotting
 * - Connects natural Hindi, Hinglish, and English queries to Gemini AI with conversation history
 * - Speaks natural TTS response and prevents self-echo recognition
 * - Exposes real-time StateFlows so the UI accurately reflects true service state
 */
class NovaVoiceService : Service(), RecognitionListener {

    private val tag = "NovaVoiceService"
    private val channelId = "nova_voice_service_channel"
    private val notificationId = 1002
    private val mainHandler = Handler(Looper.getMainLooper())
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var speechRecognizer: SpeechRecognizer? = null
    private var isRecognizerActive = false

    // Acoustic Spotter (only active when user explicitly chooses ACOUSTIC_ENERGY in Settings)
    private var audioRecord: AudioRecord? = null
    private var isRecordingAcoustic = false
    private var acousticThread: Thread? = null
    private val acousticSpotter = KeywordEnergySpotter()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        when (action) {
            ACTION_STOP -> {
                stopAssistant()
                return START_NOT_STICKY
            }
            ACTION_LISTEN -> {
                // Explicit Push-to-Talk trigger
                startListeningForCommand()
                return START_STICKY
            }
            ACTION_STOP_SPEAKING -> {
                stopSpeaking()
                return START_STICKY
            }
        }

        // Initialize Foreground Notification
        _serviceState.value = AssistantPhase.STARTING
        val notification = buildNotification("NOVA Assistant", "Starting voice service...")

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val serviceType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                } else {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_NONE
                }
                startForeground(notificationId, notification, serviceType)
            } else {
                startForeground(notificationId, notification)
            }

            isRunning = true
            evaluateListeningMode()
        } catch (e: Exception) {
            Log.e(tag, "Failed starting foreground service: ${e.message}")
            _serviceState.value = AssistantPhase.ERROR
            _statusMessage.value = "Failed to start service: ${e.message}"
            stopSelf()
        }

        return START_STICKY
    }

    private fun evaluateListeningMode() {
        val app = NovaApplication.instance
        val mode = app.getListeningMode()

        if (mode == "ACOUSTIC_ENERGY") {
            startAcousticSpotter()
        } else {
            // Push-to-Talk mode: stand by ready for button tap
            _serviceState.value = AssistantPhase.IDLE
            _statusMessage.value = "Tap microphone to speak"
            updateNotification("NOVA is Ready", "Tap to speak a command")
        }
    }

    /**
     * Acoustic Onset Monitoring loop.
     * Only runs when explicitly enabled in Settings.
     */
    private fun startAcousticSpotter() {
        if (isRecordingAcoustic || isRecognizerActive) return

        _serviceState.value = AssistantPhase.IDLE
        _statusMessage.value = "Monitoring for voice onset..."
        updateNotification("NOVA is Running", "Listening for voice onset...")

        val sampleRate = 16000
        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val audioFormat = AudioFormat.ENCODING_PCM_16BIT
        val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat).coerceAtLeast(2048)

        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                sampleRate,
                channelConfig,
                audioFormat,
                bufferSize
            )

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                Log.w(tag, "AudioRecord could not initialize")
                _serviceState.value = AssistantPhase.IDLE
                _statusMessage.value = "Microphone unavailable for background listening. Use Push-to-Talk."
                return
            }

            audioRecord?.startRecording()
            isRecordingAcoustic = true

            acousticThread = Thread({
                val buffer = ShortArray(1024)
                var speechFrames = 0

                while (isRecordingAcoustic && !Thread.currentThread().isInterrupted) {
                    val read = audioRecord?.read(buffer, 0, buffer.size) ?: -1
                    if (read > 0) {
                        val isOnset = acousticSpotter.processAudioFrame(buffer.copyOf(read))
                        if (isOnset) {
                            speechFrames++
                            if (speechFrames >= 3) {
                                mainHandler.post {
                                    startListeningForCommand()
                                }
                                break
                            }
                        } else {
                            if (speechFrames > 0) speechFrames--
                        }
                    }
                    try {
                        Thread.sleep(30)
                    } catch (e: InterruptedException) {
                        break
                    }
                }
            }, "Nova-AcousticSpotter-Thread")

            acousticThread?.start()

        } catch (e: SecurityException) {
            Log.e(tag, "AudioRecord permission denied", e)
            _serviceState.value = AssistantPhase.ERROR
            _statusMessage.value = "RECORD_AUDIO permission required"
        } catch (e: Exception) {
            Log.e(tag, "Error in acoustic recording", e)
            _serviceState.value = AssistantPhase.IDLE
            _statusMessage.value = "Background audio error. Tap microphone to speak."
        }
    }

    private fun stopAcousticSpotter() {
        isRecordingAcoustic = false
        try {
            acousticThread?.interrupt()
            acousticThread = null
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
        } catch (e: Exception) {
            Log.w(tag, "Error releasing AudioRecord", e)
        }
    }

    /**
     * Primary speech recognition entry point.
     * Safely releases AudioRecord first, then starts Android SpeechRecognizer.
     */
    fun startListeningForCommand() {
        if (isRecognizerActive) return

        // 1. Ensure AudioRecord is released before starting SpeechRecognizer
        stopAcousticSpotter()

        // 2. Ensure TTS is stopped before listening to prevent self-echo
        NovaApplication.instance.tts.stop()

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            _serviceState.value = AssistantPhase.ERROR
            _statusMessage.value = "Speech recognition is not available on this device"
            return
        }

        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(this@NovaVoiceService)
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            }

            speechRecognizer?.startListening(intent)
            isRecognizerActive = true
            _serviceState.value = AssistantPhase.LISTENING
            _statusMessage.value = "Listening to your voice..."
            updateNotification("NOVA is Listening", "Speak your command now...")
        } catch (e: Exception) {
            Log.e(tag, "Error starting SpeechRecognizer", e)
            isRecognizerActive = false
            _serviceState.value = AssistantPhase.ERROR
            _statusMessage.value = "Failed to open microphone: ${e.localizedMessage}"
            resetToIdleState()
        }
    }

    // SpeechRecognizer Callbacks
    override fun onReadyForSpeech(params: Bundle?) {
        _serviceState.value = AssistantPhase.LISTENING
        _statusMessage.value = "Listening..."
    }

    override fun onBeginningOfSpeech() {
        _serviceState.value = AssistantPhase.LISTENING
    }

    override fun onRmsChanged(rmsdB: Float) {
        _rmsLevel.value = rmsdB
    }

    override fun onBufferReceived(buffer: ByteArray?) {}

    override fun onEndOfSpeech() {
        _serviceState.value = AssistantPhase.PROCESSING
        _statusMessage.value = "Processing speech..."
        updateNotification("NOVA", "Processing command...")
    }

    override fun onError(error: Int) {
        isRecognizerActive = false
        val msg = when (error) {
            SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized. Try again."
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Listening timed out."
            SpeechRecognizer.ERROR_NETWORK -> "Network required for speech recognition."
            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission needed."
            else -> "Recognition issue (code $error)"
        }
        Log.w(tag, "Speech recognition error: $msg")
        _statusMessage.value = msg

        mainHandler.postDelayed({
            resetToIdleState()
        }, 1200)
    }

    override fun onResults(results: Bundle?) {
        isRecognizerActive = false
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val query = matches?.firstOrNull()?.trim()
        if (!query.isNullOrEmpty()) {
            _lastCommand.value = query
            executeCommand(query)
        } else {
            resetToIdleState()
        }
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val partial = matches?.firstOrNull()?.trim()
        if (!partial.isNullOrEmpty()) {
            _statusMessage.value = "\"$partial...\""
        }
    }

    override fun onEvent(eventType: Int, params: Bundle?) {}

    /**
     * Executes parsed command or routes to Gemini with conversation context.
     */
    private fun executeCommand(rawQuery: String) {
        _serviceState.value = AssistantPhase.EXECUTING_ACTION
        _statusMessage.value = "Executing: \"$rawQuery\""

        val app = NovaApplication.instance

        // Fast offline path: deterministic local parser check (<10ms)
        val fastParsed = app.commandParser.parse(rawQuery)

        if (fastParsed !is NovaCommand.Unknown && fastParsed !is NovaCommand.QueryAi) {
            val result = app.actionExecutor.execute(fastParsed)
            handleCommandResult(rawQuery, result)
            return
        }

        // Natural Language AI path with Gemini & conversation context
        if (app.geminiProvider.isConfigured) {
            _serviceState.value = AssistantPhase.PROCESSING
            _statusMessage.value = "Thinking with Gemini AI..."
            updateNotification("NOVA AI", "Thinking: \"$rawQuery\"")

            serviceScope.launch {
                // Pass recent successful conversation turns for multi-turn context
                val history = app.historyRepository.getRecentConversationTurns(maxTurns = 4)
                val aiResponse = app.geminiProvider.generateActionPlan(rawQuery, history)

                aiResponse.fold(
                    onSuccess = { jsonPlan ->
                        val mapped = app.actionDispatcher.validateAndMap(jsonPlan)
                        mapped.fold(
                            onSuccess = { command ->
                                val result = app.actionExecutor.execute(command)
                                handleCommandResult(rawQuery, result)
                            },
                            onFailure = { validationError ->
                                Log.w(tag, "Security allowlist rejected: ${validationError.message}")
                                val failResult = CommandResult.Failure(
                                    feedbackSpeech = "That action is not permitted on this phone.",
                                    errorMessage = validationError.message ?: "Security allowlist check failed"
                                )
                                handleCommandResult(rawQuery, failResult)
                            }
                        )
                    },
                    onFailure = { networkError ->
                        Log.e(tag, "Gemini network error: ${networkError.message}")
                        val failResult = CommandResult.Failure(
                            feedbackSpeech = networkError.localizedMessage ?: "Could not reach Gemini AI. Check internet connection.",
                            errorMessage = networkError.localizedMessage ?: "AI network error"
                        )
                        handleCommandResult(rawQuery, failResult)
                    }
                )
            }
        } else {
            // Free API key not set in Settings
            val fallbackResult = if (fastParsed is NovaCommand.QueryAi) {
                CommandResult.Failure(
                    feedbackSpeech = "To answer questions and understand natural Hindi and Hinglish commands, add a free Gemini API key in Settings.",
                    errorMessage = "Gemini API key not configured"
                )
            } else {
                app.actionExecutor.execute(fastParsed)
            }
            handleCommandResult(rawQuery, fallbackResult)
        }
    }

    private fun handleCommandResult(rawQuery: String, result: CommandResult) {
        _lastResult.value = result
        _serviceState.value = AssistantPhase.SPEAKING
        _statusMessage.value = result.feedbackSpeech
        updateNotification("NOVA: ${result.displayTitle}", result.feedbackSpeech)

        val app = NovaApplication.instance

        // Ensure recognizer is completely stopped while speaking so NOVA does not hear itself
        destroyRecognizer()

        app.tts.speak(result.feedbackSpeech) {
            app.historyRepository.addEntry(
                rawQuery = rawQuery,
                actionType = result.displayTitle,
                resultText = result.feedbackSpeech,
                isSuccess = result is CommandResult.Success
            )

            mainHandler.postDelayed({
                resetToIdleState()
            }, 400)
        }
    }

    fun stopSpeaking() {
        NovaApplication.instance.tts.stop()
        resetToIdleState()
    }

    private fun resetToIdleState() {
        if (!isRunning) return
        destroyRecognizer()
        evaluateListeningMode()
    }

    private fun destroyRecognizer() {
        isRecognizerActive = false
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (e: Exception) {
            Log.w(tag, "Error destroying SpeechRecognizer", e)
        }
    }

    /**
     * Completely stops assistant service
     */
    private fun stopAssistant() {
        isRunning = false
        stopAcousticSpotter()
        destroyRecognizer()
        NovaApplication.instance.tts.stop()

        _serviceState.value = AssistantPhase.STOPPED
        _statusMessage.value = "NOVA is stopped"
        stopForeground(true)
        stopSelf()
    }

    private fun buildNotification(title: String, contentText: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // Push-to-Talk action from notification
        val listenIntent = Intent(this, NovaVoiceService::class.java).apply {
            action = ACTION_LISTEN
        }
        val listenPendingIntent = PendingIntent.getService(
            this,
            2,
            listenIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, NovaVoiceService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(title)
            .setContentText(contentText)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(openPendingIntent)
            .addAction(android.R.drawable.ic_btn_speak_now, "Listen", listenPendingIntent)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification(title: String, text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(notificationId, buildNotification(title, text))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "NOVA Voice Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows live status while NOVA is ready to assist you"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        stopAssistant()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.nova.assistant.ACTION_START"
        const val ACTION_STOP = "com.nova.assistant.ACTION_STOP"
        const val ACTION_LISTEN = "com.nova.assistant.ACTION_LISTEN"
        const val ACTION_STOP_SPEAKING = "com.nova.assistant.ACTION_STOP_SPEAKING"

        var isRunning: Boolean = false
            private set

        private val _serviceState = MutableStateFlow(AssistantPhase.STOPPED)
        val serviceState: StateFlow<AssistantPhase> = _serviceState.asStateFlow()

        private val _statusMessage = MutableStateFlow("NOVA is ready to start")
        val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

        private val _lastCommand = MutableStateFlow("")
        val lastCommand: StateFlow<String> = _lastCommand.asStateFlow()

        private val _lastResult = MutableStateFlow<CommandResult?>(null)
        val lastResult: StateFlow<CommandResult?> = _lastResult.asStateFlow()

        private val _rmsLevel = MutableStateFlow(0f)
        val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

        fun startService(context: Context) {
            val intent = Intent(context, NovaVoiceService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun triggerListening(context: Context) {
            val intent = Intent(context, NovaVoiceService::class.java).apply {
                action = ACTION_LISTEN
            }
            context.startService(intent)
        }

        fun stopSpeaking(context: Context) {
            val intent = Intent(context, NovaVoiceService::class.java).apply {
                action = ACTION_STOP_SPEAKING
            }
            context.startService(intent)
        }

        fun stopService(context: Context) {
            val intent = Intent(context, NovaVoiceService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
