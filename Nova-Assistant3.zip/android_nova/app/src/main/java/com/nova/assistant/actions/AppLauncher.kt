package com.nova.assistant.actions

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.MediaStore
import android.util.Log

class AppLauncher(private val context: Context) {

    private val tag = "AppLauncher"

    // Mapping of friendly names and aliases to well-known package names or system intents
    private val knownAppPackages = mapOf(
        "youtube" to listOf("com.google.android.youtube"),
        "chrome" to listOf("com.android.chrome", "org.chromium.chrome"),
        "maps" to listOf("com.google.android.apps.maps"),
        "whatsapp" to listOf("com.whatsapp"),
        "spotify" to listOf("com.spotify.music"),
        "calculator" to listOf(
            "com.google.android.calculator",
            "com.android.calculator2",
            "com.sec.android.app.popupcalculator"
        ),
        "calendar" to listOf(
            "com.google.android.calendar",
            "com.android.calendar",
            "com.samsung.android.calendar"
        ),
        "clock" to listOf(
            "com.google.android.deskclock",
            "com.android.deskclock",
            "com.sec.android.app.clockpackage"
        ),
        "camera" to listOf(
            "com.google.android.GoogleCamera",
            "com.android.camera",
            "com.sec.android.app.camera"
        ),
        "photos" to listOf(
            "com.google.android.apps.photos",
            "com.android.gallery3d",
            "com.sec.android.gallery3d"
        ),
        "gallery" to listOf(
            "com.google.android.apps.photos",
            "com.android.gallery3d",
            "com.sec.android.gallery3d"
        ),
        "gmail" to listOf("com.google.android.gm"),
        "settings" to listOf("com.android.settings")
    )

    fun launchApp(appNameQuery: String): Result<String> {
        val query = appNameQuery.trim().lowercase()
        val pm = context.packageManager

        // Special handling for Camera (can also use ACTION_IMAGE_CAPTURE)
        if (query == "camera") {
            try {
                val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (intent.resolveActivity(pm) != null) {
                    context.startActivity(intent)
                    return Result.success("Camera opened")
                }
            } catch (e: Exception) {
                Log.w(tag, "Camera intent fallback error: ${e.message}")
            }
        }

        // 1. Check known packages
        val candidates = knownAppPackages[query]
        if (candidates != null) {
            for (pkg in candidates) {
                val launchIntent = pm.getLaunchIntentForPackage(pkg)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    return Result.success("Launched $query")
                }
            }
        }

        // 2. Dynamic search across all installed launcher applications
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfoList = pm.queryIntentActivities(mainIntent, PackageManager.MATCH_DEFAULT_ONLY)

        for (info in resolveInfoList) {
            val label = info.loadLabel(pm).toString().lowercase()
            val packageName = info.activityInfo.packageName.lowercase()

            if (label == query || label.contains(query) || packageName.contains(query)) {
                val launchIntent = pm.getLaunchIntentForPackage(info.activityInfo.packageName)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    return Result.success("Launched ${info.loadLabel(pm)}")
                }
            }
        }

        return Result.failure(
            NoSuchElementException("Could not find installed application matching '$appNameQuery'. Please check if the app is installed.")
        )
    }
}
