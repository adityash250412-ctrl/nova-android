package com.nova.assistant.voice

sealed interface SpeechState {
    object Idle : SpeechState
    object Listening : SpeechState
    data class Processing(val partialText: String = "") : SpeechState
    data class Speaking(val spokenText: String) : SpeechState
    data class Error(val message: String, val code: Int? = null) : SpeechState
}
