package com.nova.assistant.tts

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

class NovaTTS(private val context: Context) : TextToSpeech.OnInitListener {

    private val tag = "NovaTTS"
    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private var currentCallback: (() -> Unit)? = null

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.US)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.w(tag, "US English language not supported for TTS, falling back to default")
                tts?.setLanguage(Locale.getDefault())
            }
            tts?.setPitch(1.05f)
            tts?.setSpeechRate(1.02f)

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                    currentCallback?.invoke()
                    currentCallback = null
                }

                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                    currentCallback = null
                    Log.e(tag, "Error during TTS playback for utterance $utteranceId")
                }
            })

            isInitialized = true
            Log.i(tag, "NOVA TTS engine successfully initialized")
        } else {
            Log.e(tag, "Failed to initialize TTS engine. Status: $status")
            isInitialized = false
        }
    }

    fun speak(text: String, onDone: (() -> Unit)? = null) {
        if (!isInitialized || tts == null) {
            Log.w(tag, "TTS is not ready yet. Skipping utterance: $text")
            onDone?.invoke()
            return
        }

        currentCallback = onDone
        val utteranceId = UUID.randomUUID().toString()
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
        }

        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
        currentCallback = null
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isInitialized = false
    }
}
