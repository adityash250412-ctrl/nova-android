package com.nova.assistant.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.assistant.parser.CommandResult
import com.nova.assistant.service.AssistantPhase
import com.nova.assistant.ui.theme.NovaBorder
import com.nova.assistant.ui.theme.NovaCyan
import com.nova.assistant.ui.theme.NovaDeepNavy
import com.nova.assistant.ui.theme.NovaErrorRed
import com.nova.assistant.ui.theme.NovaNeonBlue
import com.nova.assistant.ui.theme.NovaPurple
import com.nova.assistant.ui.theme.NovaSuccessGreen
import com.nova.assistant.ui.theme.NovaSurfaceDark
import com.nova.assistant.ui.theme.NovaSurfaceLight
import com.nova.assistant.ui.theme.NovaTextPrimary
import com.nova.assistant.ui.theme.NovaTextSecondary

@Composable
fun HomeScreen(
    isServiceRunning: Boolean,
    phase: AssistantPhase,
    statusExplanation: String,
    hasMicPermission: Boolean,
    lastCommand: String,
    lastResult: CommandResult?,
    onStartNova: () -> Unit,
    onStopNova: () -> Unit,
    onTriggerListen: () -> Unit,
    onStopSpeaking: () -> Unit,
    onRequestMicPermission: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val scrollState = rememberScrollState()
    val isActivelyListening = phase == AssistantPhase.LISTENING
    val isSpeaking = phase == AssistantPhase.SPEAKING

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = if (isActivelyListening) 0.95f else 1.0f,
        targetValue = if (isActivelyListening) 1.14f else 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isActivelyListening) 700 else 2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaDeepNavy)
            .verticalScroll(scrollState)
            .padding(horizontal = 24.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // 1. Top Header: App Branding & Real Status Pill
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "NOVA",
                fontSize = 32.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 3.sp,
                color = NovaTextPrimary
            )
            Text(
                text = "PERSONAL VOICE ASSISTANT",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                color = NovaCyan
            )

            Spacer(modifier = Modifier.height(12.dp))

            val (pillText, pillBg, pillBorder, pillColor) = when {
                !hasMicPermission -> Quad("MIC PERMISSION NEEDED", NovaErrorRed.copy(alpha = 0.15f), NovaErrorRed, NovaErrorRed)
                phase == AssistantPhase.STARTING -> Quad("STARTING SERVICE", NovaCyan.copy(alpha = 0.2f), NovaCyan, NovaCyan)
                phase == AssistantPhase.LISTENING -> Quad("LISTENING TO VOICE", NovaCyan.copy(alpha = 0.2f), NovaCyan, NovaCyan)
                phase == AssistantPhase.PROCESSING -> Quad("PROCESSING REQUEST", NovaPurple.copy(alpha = 0.2f), NovaPurple, NovaPurple)
                phase == AssistantPhase.SPEAKING -> Quad("SPEAKING RESPONSE", NovaNeonBlue.copy(alpha = 0.2f), NovaNeonBlue, NovaNeonBlue)
                phase == AssistantPhase.EXECUTING_ACTION -> Quad("EXECUTING ACTION", NovaSuccessGreen.copy(alpha = 0.2f), NovaSuccessGreen, NovaSuccessGreen)
                phase == AssistantPhase.ERROR -> Quad("ERROR", NovaErrorRed.copy(alpha = 0.15f), NovaErrorRed, NovaErrorRed)
                isServiceRunning -> Quad("STANDBY • TAP TO SPEAK", NovaSuccessGreen.copy(alpha = 0.15f), NovaSuccessGreen, NovaSuccessGreen)
                else -> Quad("SERVICE STOPPED", NovaSurfaceLight, NovaBorder, NovaTextSecondary)
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(pillBg)
                    .border(1.dp, pillBorder.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(pillColor)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = pillText,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = pillColor
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 2. Center: Large Interactive Voice Orb
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(200.dp)
                    .scale(if (isActivelyListening) pulseScale else 1.0f)
            ) {
                // Background Glow Ring (Only active when listening or speaking)
                if (isActivelyListening || isSpeaking) {
                    Box(
                        modifier = Modifier
                            .size(190.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(
                                        if (isActivelyListening) NovaCyan.copy(alpha = 0.45f) else NovaNeonBlue.copy(alpha = 0.35f),
                                        Color.Transparent
                                    )
                                )
                            )
                    )
                }

                // Core Main Button
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(136.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                isActivelyListening -> Brush.linearGradient(listOf(NovaCyan, NovaNeonBlue))
                                isSpeaking -> Brush.linearGradient(listOf(NovaPurple, NovaNeonBlue))
                                isServiceRunning -> Brush.linearGradient(listOf(NovaSurfaceDark, NovaSurfaceLight))
                                else -> Brush.linearGradient(listOf(NovaSurfaceDark, NovaDeepNavy))
                            }
                        )
                        .border(
                            2.dp,
                            when {
                                isActivelyListening -> NovaCyan
                                isSpeaking -> NovaNeonBlue
                                isServiceRunning -> NovaCyan.copy(alpha = 0.6f)
                                else -> NovaBorder
                            },
                            CircleShape
                        )
                        .clickable {
                            if (!hasMicPermission) {
                                onRequestMicPermission()
                            } else if (!isServiceRunning) {
                                onStartNova()
                            } else if (isSpeaking) {
                                onStopSpeaking()
                            } else {
                                onTriggerListen()
                            }
                        }
                ) {
                    Icon(
                        imageVector = when {
                            isSpeaking -> Icons.Default.VolumeUp
                            isActivelyListening -> Icons.Default.GraphicEq
                            isServiceRunning -> Icons.Default.Mic
                            else -> Icons.Default.PlayArrow
                        },
                        contentDescription = "Voice Assistant Interaction",
                        tint = if (isActivelyListening || isSpeaking) NovaDeepNavy else NovaCyan,
                        modifier = Modifier.size(52.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Primary Interactive Control Action Buttons
            if (!isServiceRunning) {
                Button(
                    onClick = {
                        if (!hasMicPermission) onRequestMicPermission() else onStartNova()
                    },
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NovaCyan)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = NovaDeepNavy)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "START NOVA ASSISTANT",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp,
                        color = NovaDeepNavy
                    )
                }
            } else {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth(0.9f)
                ) {
                    // Tap to speak button (Push-to-Talk)
                    Button(
                        onClick = {
                            if (isSpeaking) onStopSpeaking() else onTriggerListen()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSpeaking) NovaPurple else NovaCyan
                        )
                    ) {
                        Icon(
                            imageVector = if (isSpeaking) Icons.Default.VolumeOff else Icons.Default.Mic,
                            contentDescription = null,
                            tint = NovaDeepNavy,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isSpeaking) "SILENCE" else if (isActivelyListening) "LISTENING" else "SPEAK",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = NovaDeepNavy
                        )
                    }

                    // Stop service button
                    Button(
                        onClick = onStopNova,
                        modifier = Modifier
                            .weight(0.7f)
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NovaSurfaceLight)
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = null, tint = NovaTextSecondary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "STOP",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = NovaTextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Explanation of what NOVA is doing
            Text(
                text = statusExplanation,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                color = if (isActivelyListening) NovaCyan else if (isSpeaking) NovaNeonBlue else NovaTextSecondary,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 3. Bottom: Recent Command, Result, and Hint Card
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (lastCommand.isNotEmpty() || lastResult != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(NovaSurfaceDark)
                        .border(1.dp, NovaBorder, RoundedCornerShape(14.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "LATEST INTERACTION",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = NovaCyan
                            )
                            if (lastResult != null) {
                                Icon(
                                    imageVector = if (lastResult is CommandResult.Success) Icons.Default.CheckCircle else Icons.Default.Error,
                                    contentDescription = null,
                                    tint = if (lastResult is CommandResult.Success) NovaSuccessGreen else NovaErrorRed,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        if (lastCommand.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "\"$lastCommand\"",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = NovaTextPrimary
                            )
                        }

                        if (lastResult != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = lastResult.feedbackSpeech,
                                fontSize = 12.sp,
                                color = NovaTextSecondary,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(NovaSurfaceDark)
                        .border(1.dp, NovaBorder, RoundedCornerShape(14.dp))
                        .padding(14.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "Tap Speak and say \"YouTube kholo\" or \"Torch on karo\"",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = NovaTextSecondary,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Supports Hindi, Hinglish & English phone controls and Gemini AI answers",
                            fontSize = 10.sp,
                            color = NovaCyan,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (!hasMicPermission) {
                Text(
                    text = "Microphone permission required for voice. Tap here to grant.",
                    fontSize = 11.sp,
                    color = NovaErrorRed,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .clickable { onRequestMicPermission() }
                        .padding(vertical = 4.dp)
                )
            } else {
                Text(
                    text = "Push-to-Talk active • Tap Speak anytime to issue commands",
                    fontSize = 11.sp,
                    color = NovaTextSecondary,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
