import React, { useState } from 'react';
import {
  Download,
  CheckCircle2,
  ShieldCheck,
  AlertTriangle,
  Smartphone,
  Copy,
  Check,
  FileCode,
  Github,
  ExternalLink,
  Layers,
  ArrowRight,
  Terminal,
  FileArchive,
  Info
} from 'lucide-react';

const WORKFLOW_YAML = `name: Build Android Debug APK

on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
  workflow_dispatch:

jobs:
  build:
    name: Build Debug APK
    runs-on: ubuntu-latest
    timeout-minutes: 20

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'

      - name: Setup Gradle
        uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.10.2'
          cache-read-only: false

      - name: Make gradlew executable
        run: chmod +x gradlew

      - name: Build Debug APK
        run: ./gradlew assembleDebug --stacktrace --no-daemon

      - name: Verify APK output exists
        run: |
          if [ -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
            echo "SUCCESS: app-debug.apk was generated!"
            ls -lh app/build/outputs/apk/debug/app-debug.apk
          else
            echo "ERROR: app/build/outputs/apk/debug/app-debug.apk was not found!"
            exit 1
          fi

      - name: Upload Debug APK
        uses: actions/upload-artifact@v4
        with:
          name: nova-assistant-debug-apk
          path: app/build/outputs/apk/debug/app-debug.apk
          retention-days: 14`;

export default function App() {
  const [copied, setCopied] = useState(false);
  const [copiedHash, setCopiedHash] = useState(false);
  const [activeTab, setActiveTab] = useState<'guide' | 'changes' | 'workflow' | 'specs'>('guide');

  const copyToClipboard = (text: string, isHash = false) => {
    navigator.clipboard.writeText(text);
    if (isHash) {
      setCopiedHash(true);
      setTimeout(() => setCopiedHash(false), 2000);
    } else {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const zipDownloadUrl = "/downloads/nova-android-project-ready.zip";
  const wrapperHash = "2db75c40782f5e8ba1fc278a5574bab070adccb2d21ca5a6e5ed840888448046";
  const bundleHash = "c99bfab5fed058a87fb47913624e738ca37c8757afeb434a0738eb7758183b06";

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-indigo-500 selection:text-white">
      {/* Top Header */}
      <header className="border-b border-slate-800/80 bg-slate-900/60 backdrop-blur sticky top-0 z-30 px-4 sm:px-8 py-3.5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-cyan-500 flex items-center justify-center font-bold shadow-lg shadow-indigo-500/20 text-white">
            N
          </div>
          <div>
            <h1 className="font-semibold text-sm sm:text-base tracking-tight leading-none text-white">
              NOVA Assistant <span className="text-indigo-400 font-mono text-xs px-1.5 py-0.5 rounded bg-indigo-950/80 border border-indigo-800/50 ml-1.5">v1.0.0</span>
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              ₹0 Cloud Android APK Build Hub
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <a
            href={zipDownloadUrl}
            download="nova-android-project-ready.zip"
            className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white text-xs sm:text-sm font-medium px-3.5 py-2 rounded-lg transition-colors shadow-sm shadow-indigo-500/30"
          >
            <Download className="w-4 h-4" />
            <span>Download ZIP (94 KB)</span>
          </a>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
        
        {/* Status Alert Banner */}
        <div className="rounded-xl border border-amber-500/30 bg-amber-950/20 p-4 sm:p-5 flex flex-col sm:flex-row sm:items-start gap-3.5">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h2 className="text-sm font-semibold text-amber-200">
              Build Status: Bundle Prepared & Ready for Cloud Execution
            </h2>
            <p className="text-xs sm:text-sm text-amber-300/80 leading-relaxed">
              <strong>Honest verification note:</strong> An installable Android APK does not exist yet because this web sandbox cannot compile native Android binaries. To get your APK at ₹0 with only your phone, follow the 4-step GitHub Actions build flow below.
            </p>
          </div>
        </div>

        {/* Hero Card: Direct Download & Summary */}
        <div className="bg-gradient-to-b from-slate-900 to-slate-900/90 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
            <div className="md:col-span-2 space-y-3">
              <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Gradle 8.10.2 Wrapper Verified &amp; Packaged</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                Download the Ready-to-Build Project Bundle
              </h2>
              <p className="text-sm text-slate-300 leading-relaxed">
                Contains the complete NOVA voice assistant source code, the official verified Gradle 8.10.2 wrapper jar, Android SDK 35 build configuration, and automated GitHub Actions workflow.
              </p>

              <div className="flex flex-wrap gap-2 text-xs text-slate-400 pt-1">
                <span className="bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700/60 font-mono">
                  AGP: 8.8.0
                </span>
                <span className="bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700/60 font-mono">
                  Kotlin: 2.0.21
                </span>
                <span className="bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700/60 font-mono">
                  CompileSdk: 35
                </span>
                <span className="bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700/60 font-mono">
                  Java: 17
                </span>
              </div>
            </div>

            <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 flex flex-col justify-center items-center text-center space-y-3">
              <FileArchive className="w-10 h-10 text-indigo-400" />
              <div>
                <p className="font-semibold text-sm text-white">nova-android-project-ready.zip</p>
                <p className="text-xs text-slate-400">55 files &bull; 94 KB &bull; Standard ZIP</p>
              </div>
              <a
                href={zipDownloadUrl}
                download="nova-android-project-ready.zip"
                className="w-full flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-medium py-2.5 px-4 rounded-xl transition text-sm shadow-lg shadow-indigo-600/30"
              >
                <Download className="w-4 h-4" />
                <span>Download Bundle</span>
              </a>
              <button
                onClick={() => copyToClipboard(bundleHash, true)}
                className="text-[11px] text-slate-400 hover:text-slate-200 transition flex items-center gap-1 font-mono truncate max-w-full"
                title="Click to copy ZIP SHA-256"
              >
                {copiedHash ? (
                  <span className="text-emerald-400 flex items-center gap-1"><Check className="w-3 h-3" /> Hash copied!</span>
                ) : (
                  <span>SHA256: {bundleHash.slice(0, 10)}... <Copy className="w-2.5 h-2.5 inline" /></span>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-800 space-x-1 sm:space-x-2 overflow-x-auto pb-px">
          <button
            onClick={() => setActiveTab('guide')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-medium border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'guide'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>Phone-Only Build Guide (4 Steps)</span>
          </button>

          <button
            onClick={() => setActiveTab('changes')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-medium border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'changes'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Files Added &amp; Integrity Audit</span>
          </button>

          <button
            onClick={() => setActiveTab('workflow')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-medium border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'workflow'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCode className="w-4 h-4" />
            <span>GitHub Actions YAML</span>
          </button>

          <button
            onClick={() => setActiveTab('specs')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-medium border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'specs'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Project Specifications</span>
          </button>
        </div>

        {/* Tab 1: Phone-Only Build Guide */}
        {activeTab === 'guide' && (
          <div className="space-y-4">
            <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 sm:p-5">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2 mb-2">
                <Github className="w-4 h-4 text-slate-300" />
                How to compile and get the APK entirely on your Android Phone
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                You do not need a laptop or computer. GitHub Actions provides free cloud Ubuntu runners equipped with JDK 17 and Android SDK 35. Follow these 4 steps on your phone:
              </p>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {/* Step 1 */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 sm:p-5 flex gap-4">
                <div className="w-8 h-8 rounded-full bg-indigo-600/20 border border-indigo-500/40 text-indigo-400 flex items-center justify-center font-bold text-sm shrink-0">
                  1
                </div>
                <div className="space-y-2 flex-1">
                  <h4 className="text-sm font-semibold text-white">Download &amp; Extract the Project ZIP</h4>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    Tap the <strong>Download Bundle</strong> button above to save <code className="text-indigo-300 font-mono text-xs bg-slate-800 px-1 py-0.5 rounded">nova-android-project-ready.zip</code>. On your phone, open your <strong>Files</strong> or <strong>My Files</strong> app and tap <strong>Extract</strong>.
                  </p>
                </div>
              </div>

              {/* Step 2 */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 sm:p-5 flex gap-4">
                <div className="w-8 h-8 rounded-full bg-indigo-600/20 border border-indigo-500/40 text-indigo-400 flex items-center justify-center font-bold text-sm shrink-0">
                  2
                </div>
                <div className="space-y-2 flex-1">
                  <h4 className="text-sm font-semibold text-white">Create a Free Repository on GitHub</h4>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    Open your phone browser (Chrome) and visit <a href="https://github.com/new" target="_blank" rel="noopener noreferrer" className="text-indigo-400 underline font-mono text-xs">github.com/new</a>. Create a new repository named <code className="text-indigo-300 font-mono text-xs bg-slate-800 px-1 py-0.5 rounded">nova-android</code> (Public or Private).
                  </p>
                  <p className="text-xs text-slate-400">
                    On the repository page, tap <strong>uploading an existing file</strong> and select the extracted project files (make sure the <code className="text-indigo-300 font-mono">.github/workflows</code> folder is uploaded). Tap <strong>Commit changes</strong>.
                  </p>
                </div>
              </div>

              {/* Step 3 */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 sm:p-5 flex gap-4">
                <div className="w-8 h-8 rounded-full bg-indigo-600/20 border border-indigo-500/40 text-indigo-400 flex items-center justify-center font-bold text-sm shrink-0">
                  3
                </div>
                <div className="space-y-2 flex-1">
                  <h4 className="text-sm font-semibold text-white">Trigger the Automated Cloud Build</h4>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    In your GitHub repository, tap the <strong>Actions</strong> tab. Tap on <strong>Build Android Debug APK</strong>.
                  </p>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    Tap the <strong>Run workflow</strong> dropdown button, select branch <code className="text-indigo-300 font-mono text-xs bg-slate-800 px-1 py-0.5 rounded">main</code>, and tap the green <strong>Run workflow</strong> button. The runner will start immediately.
                  </p>
                  <div className="p-3 bg-slate-950/80 rounded-lg border border-slate-800 text-xs text-slate-400">
                    ⏱️ <strong>Estimated time:</strong> 2 to 3 minutes. The runner sets up JDK 17, installs Android SDK 35, and compiles <code className="text-indigo-300 font-mono">./gradlew assembleDebug</code>.
                  </div>
                </div>
              </div>

              {/* Step 4 */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 sm:p-5 flex gap-4">
                <div className="w-8 h-8 rounded-full bg-emerald-600/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center font-bold text-sm shrink-0">
                  4
                </div>
                <div className="space-y-2 flex-1">
                  <h4 className="text-sm font-semibold text-white">Download &amp; Install the APK on Your Phone</h4>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    When the run finishes with a green checkmark (✓), tap it. Scroll to the bottom to find the <strong>Artifacts</strong> section.
                  </p>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    Tap <strong>nova-assistant-debug-apk</strong>. Your phone will download the ZIP containing <code className="text-emerald-400 font-semibold font-mono text-xs bg-slate-800 px-1 py-0.5 rounded">app-debug.apk</code>. Tap it in your notifications or Files app to install!
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Changes & Audit */}
        {activeTab === 'changes' && (
          <div className="space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                Exact Changes Applied &amp; Cryptographic Verification
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                As per your instructions, no source code or app features were modified. Only the missing build tools and CI configuration were injected to solve the build blocker.
              </p>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border border-slate-800 rounded-lg overflow-hidden">
                  <thead className="bg-slate-950/80 text-slate-400 uppercase font-mono">
                    <tr>
                      <th className="py-2.5 px-3">File Path</th>
                      <th className="py-2.5 px-3">Status</th>
                      <th className="py-2.5 px-3">Details / Verification</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 font-mono text-slate-300">
                    <tr className="bg-slate-900/40">
                      <td className="py-2.5 px-3 text-indigo-300 font-medium">gradle/wrapper/gradle-wrapper.jar</td>
                      <td className="py-2.5 px-3 text-emerald-400 font-bold">ADDED</td>
                      <td className="py-2.5 px-3 text-slate-400 text-[11px] font-sans">
                        Official Gradle 8.10.2 binary (43,158 bytes).
                        <br />
                        <span className="font-mono text-[10px] text-slate-400">
                          SHA-256: 2db75c40782f5e8ba1fc278a5574bab070adccb2d21ca5a6e5ed840888448046
                        </span>
                        <br />
                        <span className="text-emerald-400 text-[11px] font-sans">
                          ✓ Matches official services.gradle.org wrapperChecksum
                        </span>
                      </td>
                    </tr>
                    <tr className="bg-slate-900/20">
                      <td className="py-2.5 px-3 text-indigo-300 font-medium">.github/workflows/build-apk.yml</td>
                      <td className="py-2.5 px-3 text-emerald-400 font-bold">ADDED</td>
                      <td className="py-2.5 px-3 text-slate-400 text-[11px] font-sans">
                        Cloud CI workflow: Sets up Temurin JDK 17, Android SDK 35, runs <code className="text-slate-300 font-mono">./gradlew assembleDebug</code>, and uploads <code className="text-slate-300 font-mono">app-debug.apk</code>.
                      </td>
                    </tr>
                    <tr className="bg-slate-900/40">
                      <td className="py-2.5 px-3 text-indigo-300 font-medium">README.md</td>
                      <td className="py-2.5 px-3 text-emerald-400 font-bold">ADDED</td>
                      <td className="py-2.5 px-3 text-slate-400 text-[11px] font-sans">
                        Complete phone-first compilation guide and project specifications.
                      </td>
                    </tr>
                    <tr className="bg-slate-900/20">
                      <td className="py-2.5 px-3 text-indigo-300 font-medium">.gitignore</td>
                      <td className="py-2.5 px-3 text-emerald-400 font-bold">ADDED</td>
                      <td className="py-2.5 px-3 text-slate-400 text-[11px] font-sans">
                        Standard Android gitignore with explicit exemption <code className="text-slate-300 font-mono">!gradle/wrapper/gradle-wrapper.jar</code> to prevent accidental git omission.
                      </td>
                    </tr>
                    <tr className="bg-slate-900/40">
                      <td className="py-2.5 px-3 text-indigo-300 font-medium">gradlew</td>
                      <td className="py-2.5 px-3 text-sky-400 font-bold">PERMISSIONS</td>
                      <td className="py-2.5 px-3 text-slate-400 text-[11px] font-sans">
                        Ensured executable permissions bit (<code className="text-slate-300 font-mono">+x</code>) for Linux runners.
                      </td>
                    </tr>
                    <tr className="bg-slate-900/20">
                      <td className="py-2.5 px-3 text-slate-400">All 44 Kotlin &amp; Resource files</td>
                      <td className="py-2.5 px-3 text-slate-400 font-bold">UNTOUCHED</td>
                      <td className="py-2.5 px-3 text-slate-400 text-[11px] font-sans">
                        Existing NOVA app logic, UI, and voice services completely preserved.
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Workflow Code */}
        {activeTab === 'workflow' && (
          <div className="space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-white">.github/workflows/build-apk.yml</h3>
                  <p className="text-xs text-slate-400">Packaged inside the ZIP ready to run on GitHub</p>
                </div>
                <button
                  onClick={() => copyToClipboard(WORKFLOW_YAML)}
                  className="flex items-center gap-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg border border-slate-700 transition"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400 font-medium">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy YAML</span>
                    </>
                  )}
                </button>
              </div>

              <pre className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 font-mono text-xs text-indigo-200/90 overflow-x-auto leading-relaxed">
                {WORKFLOW_YAML}
              </pre>
            </div>
          </div>
        )}

        {/* Tab 4: Specifications */}
        {activeTab === 'specs' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono">
                Build Configuration
              </h4>
              <ul className="text-xs sm:text-sm space-y-2 text-slate-300">
                <li className="flex justify-between border-b border-slate-800/60 pb-1.5">
                  <span className="text-slate-400">Application ID:</span>
                  <span className="font-mono text-indigo-300">com.nova.assistant</span>
                </li>
                <li className="flex justify-between border-b border-slate-800/60 pb-1.5">
                  <span className="text-slate-400">Compile SDK:</span>
                  <span className="font-mono text-indigo-300">35 (Android 15)</span>
                </li>
                <li className="flex justify-between border-b border-slate-800/60 pb-1.5">
                  <span className="text-slate-400">Target SDK:</span>
                  <span className="font-mono text-indigo-300">35 (Android 15)</span>
                </li>
                <li className="flex justify-between border-b border-slate-800/60 pb-1.5">
                  <span className="text-slate-400">Min SDK:</span>
                  <span className="font-mono text-indigo-300">26 (Android 8.0)</span>
                </li>
                <li className="flex justify-between border-b border-slate-800/60 pb-1.5">
                  <span className="text-slate-400">Version Code / Name:</span>
                  <span className="font-mono text-indigo-300">1 (v1.0.0)</span>
                </li>
              </ul>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono">
                Toolchain Versions
              </h4>
              <ul className="text-xs sm:text-sm space-y-2 text-slate-300">
                <li className="flex justify-between border-b border-slate-800/60 pb-1.5">
                  <span className="text-slate-400">Android Gradle Plugin:</span>
                  <span className="font-mono text-indigo-300">8.8.0</span>
                </li>
                <li className="flex justify-between border-b border-slate-800/60 pb-1.5">
                  <span className="text-slate-400">Kotlin Version:</span>
                  <span className="font-mono text-indigo-300">2.0.21</span>
                </li>
                <li className="flex justify-between border-b border-slate-800/60 pb-1.5">
                  <span className="text-slate-400">Gradle Wrapper:</span>
                  <span className="font-mono text-indigo-300">8.10.2</span>
                </li>
                <li className="flex justify-between border-b border-slate-800/60 pb-1.5">
                  <span className="text-slate-400">Java Virtual Machine:</span>
                  <span className="font-mono text-indigo-300">JDK 17 (Temurin)</span>
                </li>
                <li className="flex justify-between border-b border-slate-800/60 pb-1.5">
                  <span className="text-slate-400">Compose BOM:</span>
                  <span className="font-mono text-indigo-300">2024.12.01</span>
                </li>
              </ul>
            </div>
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-900/40 text-center py-4 px-4 text-xs text-slate-400">
        NOVA Assistant &bull; 100% Free Cloud Android Build &bull; GitHub Actions Compatible
      </footer>
    </div>
  );
}
