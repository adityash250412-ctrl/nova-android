package com.nova.assistant

import android.app.Application
import com.nova.assistant.actions.ActionExecutor
import com.nova.assistant.actions.AppLauncher
import com.nova.assistant.actions.ContactCaller
import com.nova.assistant.actions.FlashlightController
import com.nova.assistant.actions.SearchLauncher
import com.nova.assistant.actions.SettingsLauncher
import com.nova.assistant.actions.VolumeController
import com.nova.assistant.history.CommandHistoryRepository
import com.nova.assistant.parser.CommandParser
import com.nova.assistant.tts.NovaTTS

class NovaApplication : Application() {

    lateinit var flashlightController: FlashlightController
        private set

    lateinit var appLauncher: AppLauncher
        private set

    lateinit var settingsLauncher: SettingsLauncher
        private set

    lateinit var contactCaller: ContactCaller
        private set

    lateinit var searchLauncher: SearchLauncher
        private set

    lateinit var volumeController: VolumeController
        private set

    lateinit var actionExecutor: ActionExecutor
        private set

    lateinit var commandParser: CommandParser
        private set

    lateinit var tts: NovaTTS
        private set

    lateinit var historyRepository: CommandHistoryRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        flashlightController = FlashlightController(this)
        appLauncher = AppLauncher(this)
        settingsLauncher = SettingsLauncher(this)
        contactCaller = ContactCaller(this)
        searchLauncher = SearchLauncher(this)
        volumeController = VolumeController(this)

        actionExecutor = ActionExecutor(
            this,
            flashlightController,
            appLauncher,
            settingsLauncher,
            contactCaller,
            searchLauncher,
            volumeController
        )
        commandParser = CommandParser()
        tts = NovaTTS(this)
        historyRepository = CommandHistoryRepository(this)
    }

    override fun onTerminate() {
        super.onTerminate()
        tts.shutdown()
        flashlightController.release()
    }

    companion object {
        lateinit var instance: NovaApplication
            private set
    }
}
