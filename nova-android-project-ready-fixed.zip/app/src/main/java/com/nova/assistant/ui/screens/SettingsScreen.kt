package com.nova.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.assistant.ui.theme.NovaBorder
import com.nova.assistant.ui.theme.NovaCyan
import com.nova.assistant.ui.theme.NovaDeepNavy
import com.nova.assistant.ui.theme.NovaNeonBlue
import com.nova.assistant.ui.theme.NovaPurple
import com.nova.assistant.ui.theme.NovaSuccessGreen
import com.nova.assistant.ui.theme.NovaSurfaceDark
import com.nova.assistant.ui.theme.NovaSurfaceLight
import com.nova.assistant.ui.theme.NovaTextPrimary
import com.nova.assistant.ui.theme.NovaTextSecondary

@Composable
fun SettingsScreen(
    isAccessibilityEnabled: Boolean,
    isFlashlightOn: Boolean,
    onToggleFlashlight: () -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onTestTTS: () -> Unit
) {
    val scrollState = rememberScrollState()
    var geminiKey by remember { mutableStateOf("") }
    var selectedProvider by remember { mutableStateOf("Local Regex (Free & Offline)") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaDeepNavy)
            .verticalScroll(scrollState)
            .padding(20.dp)
    ) {
        // Header
        Text(
            text = "SETTINGS & PERMISSIONS",
            fontSize = 20.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp,
            color = NovaTextPrimary
        )
        Text(
            text = "Configure phone control, accessibility, and AI providers",
            fontSize = 12.sp,
            color = NovaTextSecondary
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Section 1: Phone Control Hardware
        SettingsSectionHeader(title = "HARDWARE & PHONE CONTROL", icon = Icons.Default.FlashlightOn)
        
        SettingCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Camera Flashlight / Torch",
                        color = NovaTextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Toggle the device rear LED flashlight via CameraManager",
                        color = NovaTextSecondary,
                        fontSize = 11.sp
                    )
                }
                Switch(
                    checked = isFlashlightOn,
                    onCheckedChange = { onToggleFlashlight() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = NovaDeepNavy,
                        checkedTrackColor = NovaCyan,
                        uncheckedThumbColor = NovaTextSecondary,
                        uncheckedTrackColor = NovaSurfaceLight
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Section 2: Speech & TTS
        SettingsSectionHeader(title = "SPEECH RECOGNITION & TTS", icon = Icons.Default.VolumeUp)
        
        SettingCard {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Audio Feedback (TTS)",
                            color = NovaTextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Android TextToSpeech engine with US English synthesis",
                            color = NovaTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Button(
                        onClick = onTestTTS,
                        colors = ButtonDefaults.buttonColors(containerColor = NovaCyan),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Test Voice", color = NovaDeepNavy, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Section 3: Phase 2 Accessibility Automation
        SettingsSectionHeader(title = "PHASE 2: ACCESSIBILITY SERVICE", icon = Icons.Default.AccessibilityNew)
        
        SettingCard {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Nova Accessibility Automation",
                            color = NovaTextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (isAccessibilityEnabled) "Status: AUTHORIZED & ACTIVE" else "Status: NOT ENABLED (Optional)",
                            color = if (isAccessibilityEnabled) NovaSuccessGreen else NovaCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Button(
                        onClick = onOpenAccessibilitySettings,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isAccessibilityEnabled) NovaSurfaceLight else NovaCyan
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = if (isAccessibilityEnabled) "Config" else "Enable",
                            color = if (isAccessibilityEnabled) NovaTextPrimary else NovaDeepNavy,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(NovaDeepNavy)
                        .padding(10.dp)
                ) {
                    Text(
                        text = "SECURITY NOTICE: Android requires explicit user authorization in System Settings. NOVA will never silently inspect screens or bypass lock screen security.",
                        color = NovaTextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 14.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Section 4: Phase 4 AI Provider Configuration
        SettingsSectionHeader(title = "PHASE 4: MODULAR AI PROVIDER", icon = Icons.Default.Psychology)
        
        SettingCard {
            Column {
                Text(
                    text = "Active Parser Engine",
                    color = NovaTextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Initial version operates 100% free and offline without requiring API keys.",
                    color = NovaTextSecondary,
                    fontSize = 11.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val providers = listOf("Local Offline", "Google Gemini", "Claude")
                    providers.forEach { p ->
                        val isSelected = (p == "Local Offline" && selectedProvider.startsWith("Local")) || selectedProvider == p
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) NovaCyan.copy(alpha = 0.2f) else NovaDeepNavy)
                                .border(1.dp, if (isSelected) NovaCyan else NovaBorder, RoundedCornerShape(8.dp))
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = p,
                                color = if (isSelected) NovaCyan else NovaTextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = geminiKey,
                    onValueChange = { geminiKey = it },
                    label = { Text("Optional Gemini API Key", fontSize = 12.sp) },
                    placeholder = { Text("Not required for local phone control", fontSize = 12.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NovaCyan,
                        unfocusedBorderColor = NovaBorder,
                        focusedTextColor = NovaTextPrimary,
                        unfocusedTextColor = NovaTextPrimary
                    ),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Security Guarantee: Keys are never embedded in the compiled APK. Stored locally in Android Keystore.",
                    color = NovaTextSecondary,
                    fontSize = 10.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

@Composable
fun SettingsSectionHeader(title: String, icon: ImageVector) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(bottom = 8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = NovaCyan,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = title,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            color = NovaCyan
        )
    }
}

@Composable
fun SettingCard(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(NovaSurfaceDark)
            .border(1.dp, NovaBorder, RoundedCornerShape(12.dp))
            .padding(16.dp)
    ) {
        content()
    }
}
