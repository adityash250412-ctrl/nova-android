package com.nova.assistant.actions

import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.nova.assistant.parser.SettingTarget

class SettingsLauncher(private val context: Context) {

    fun launchSettings(target: SettingTarget): Result<String> {
        val action = when (target) {
            SettingTarget.Wifi -> Settings.ACTION_WIFI_SETTINGS
            SettingTarget.Bluetooth -> Settings.ACTION_BLUETOOTH_SETTINGS
            SettingTarget.Display -> Settings.ACTION_DISPLAY_SETTINGS
            SettingTarget.Sound -> Settings.ACTION_SOUND_SETTINGS
            SettingTarget.Battery -> {
                // Battery saver or main settings
                Settings.ACTION_BATTERY_SAVER_SETTINGS
            }
            SettingTarget.Apps -> Settings.ACTION_APPLICATION_SETTINGS
            SettingTarget.Accessibility -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            SettingTarget.Location -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            SettingTarget.General -> Settings.ACTION_SETTINGS
        }

        return try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success("Opened ${target.nameKey} settings")
        } catch (e: Exception) {
            // Fallback to general settings if specific subpage is not found on device
            try {
                val fallbackIntent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallbackIntent)
                Result.success("Opened general settings (sub-setting unsupported on this device)")
            } catch (err: Exception) {
                Result.failure(err)
            }
        }
    }
}
