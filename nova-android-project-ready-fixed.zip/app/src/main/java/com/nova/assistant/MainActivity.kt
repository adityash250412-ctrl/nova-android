package com.nova.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.nova.assistant.accessibility.AccessibilityHelper
import com.nova.assistant.service.AssistantPhase
import com.nova.assistant.service.NovaVoiceService
import com.nova.assistant.ui.screens.HistoryScreen
import com.nova.assistant.ui.screens.HomeScreen
import com.nova.assistant.ui.screens.SettingsScreen
import com.nova.assistant.ui.theme.NOVATheme
import com.nova.assistant.ui.theme.NovaCyan
import com.nova.assistant.ui.theme.NovaDeepNavy
import com.nova.assistant.ui.theme.NovaSurfaceDark
import com.nova.assistant.ui.theme.NovaTextSecondary

class MainActivity : ComponentActivity() {

    private lateinit var app: NovaApplication
    private var hasMicPermission by mutableStateOf(false)

    // Permission launcher for microphone & notifications
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val micGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        hasMicPermission = micGranted

        if (micGranted) {
            Toast.makeText(this, "Microphone permission granted", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Microphone permission is required for NOVA voice control", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = application as NovaApplication
        checkPermissions()

        setContent {
            NOVATheme {
                NovaAppContent()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        checkPermissions()
    }

    private fun checkPermissions() {
        hasMicPermission = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestPermissions() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        requestPermissionLauncher.launch(permissions.toTypedArray())
    }

    private fun startNova() {
        if (!hasMicPermission) {
            requestPermissions()
            return
        }
        NovaVoiceService.startService(this)
    }

    private fun stopNova() {
        NovaVoiceService.stopService(this)
    }

    @Composable
    private fun NovaAppContent() {
        var currentTab by remember { mutableStateOf(0) }
        val servicePhase by NovaVoiceService.serviceState.collectAsState()
        val statusExplanation by NovaVoiceService.statusMessage.collectAsState()
        val lastCommand by NovaVoiceService.lastCommand.collectAsState()
        val lastResult by NovaVoiceService.lastResult.collectAsState()
        val historyList by app.historyRepository.history.collectAsState()
        val isAccessibilityEnabled = AccessibilityHelper.isAccessibilityServiceEnabled(this)

        val isRunning = servicePhase != AssistantPhase.STOPPED && servicePhase != AssistantPhase.ERROR

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = NovaDeepNavy,
            bottomBar = {
                NavigationBar(
                    containerColor = NovaSurfaceDark,
                    tonalElevation = 4.dp
                ) {
                    NavigationBarItem(
                        selected = currentTab == 0,
                        onClick = { currentTab = 0 },
                        icon = { Icon(Icons.Default.Mic, contentDescription = "Voice Assistant", modifier = Modifier.size(22.dp)) },
                        label = { Text("Assistant", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NovaDeepNavy,
                            selectedTextColor = NovaCyan,
                            indicatorColor = NovaCyan,
                            unselectedIconColor = NovaTextSecondary,
                            unselectedTextColor = NovaTextSecondary
                        )
                    )
                    NavigationBarItem(
                        selected = currentTab == 1,
                        onClick = { currentTab = 1 },
                        icon = { Icon(Icons.Default.History, contentDescription = "Command History", modifier = Modifier.size(22.dp)) },
                        label = { Text("History", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NovaDeepNavy,
                            selectedTextColor = NovaCyan,
                            indicatorColor = NovaCyan,
                            unselectedIconColor = NovaTextSecondary,
                            unselectedTextColor = NovaTextSecondary
                        )
                    )
                    NavigationBarItem(
                        selected = currentTab == 2,
                        onClick = { currentTab = 2 },
                        icon = { Icon(Icons.Default.Settings, contentDescription = "Settings", modifier = Modifier.size(22.dp)) },
                        label = { Text("Settings", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NovaDeepNavy,
                            selectedTextColor = NovaCyan,
                            indicatorColor = NovaCyan,
                            unselectedIconColor = NovaTextSecondary,
                            unselectedTextColor = NovaTextSecondary
                        )
                    )
                }
            }
        ) { paddingValues ->
            Box(modifier = Modifier.padding(paddingValues)) {
                when (currentTab) {
                    0 -> HomeScreen(
                        isServiceRunning = isRunning,
                        phase = servicePhase,
                        statusExplanation = statusExplanation,
                        hasMicPermission = hasMicPermission,
                        lastCommand = lastCommand,
                        lastResult = lastResult,
                        onStartNova = { startNova() },
                        onStopNova = { stopNova() },
                        onRequestMicPermission = { requestPermissions() },
                        onNavigateToSettings = { currentTab = 2 }
                    )
                    1 -> HistoryScreen(
                        historyItems = historyList,
                        onClearHistory = { app.historyRepository.clearHistory() }
                    )
                    2 -> SettingsScreen(
                        isAccessibilityEnabled = isAccessibilityEnabled,
                        isFlashlightOn = app.flashlightController.isTorchOn,
                        onToggleFlashlight = {
                            val res = app.flashlightController.toggle()
                            res.onFailure {
                                Toast.makeText(this@MainActivity, it.message, Toast.LENGTH_SHORT).show()
                            }
                        },
                        onOpenAccessibilitySettings = {
                            AccessibilityHelper.openAccessibilitySettings(this@MainActivity)
                        },
                        onTestTTS = {
                            app.tts.speak("NOVA voice synthesis is operational.")
                        }
                    )
                }
            }
        }
    }
}
