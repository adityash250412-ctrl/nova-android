package com.nova.assistant.history

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class CommandHistoryItem(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val rawQuery: String,
    val actionType: String,
    val resultText: String,
    val isSuccess: Boolean
) {
    val formattedTime: String
        get() = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(timestamp))
}

class CommandHistoryRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("nova_history_prefs", Context.MODE_PRIVATE)

    private val _history = MutableStateFlow<List<CommandHistoryItem>>(emptyList())
    val history: StateFlow<List<CommandHistoryItem>> = _history.asStateFlow()

    init {
        loadHistory()
    }

    private fun loadHistory() {
        val raw = prefs.getString("history_items", "[]") ?: "[]"
        try {
            val array = JSONArray(raw)
            val list = mutableListOf<CommandHistoryItem>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    CommandHistoryItem(
                        id = obj.getString("id"),
                        timestamp = obj.getLong("timestamp"),
                        rawQuery = obj.getString("rawQuery"),
                        actionType = obj.getString("actionType"),
                        resultText = obj.getString("resultText"),
                        isSuccess = obj.getBoolean("isSuccess")
                    )
                )
            }
            _history.value = list
        } catch (e: Exception) {
            _history.value = emptyList()
        }
    }

    fun addEntry(rawQuery: String, actionType: String, resultText: String, isSuccess: Boolean) {
        val newItem = CommandHistoryItem(
            rawQuery = rawQuery,
            actionType = actionType,
            resultText = resultText,
            isSuccess = isSuccess
        )
        val currentList = _history.value.toMutableList()
        currentList.add(0, newItem) // most recent first
        if (currentList.size > 100) {
            currentList.removeAt(currentList.lastIndex)
        }
        _history.value = currentList
        persist(currentList)
    }

    fun clearHistory() {
        _history.value = emptyList()
        prefs.edit().remove("history_items").apply()
    }

    private fun persist(list: List<CommandHistoryItem>) {
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("timestamp", item.timestamp)
                put("rawQuery", item.rawQuery)
                put("actionType", item.actionType)
                put("resultText", item.resultText)
                put("isSuccess", item.isSuccess)
            }
            array.put(obj)
        }
        prefs.edit().putString("history_items", array.toString()).apply()
    }
}
