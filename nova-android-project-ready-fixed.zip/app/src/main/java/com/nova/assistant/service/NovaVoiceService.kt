package com.nova.assistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.app.NotificationCompat
import com.nova.assistant.MainActivity
import com.nova.assistant.NovaApplication
import com.nova.assistant.R
import com.nova.assistant.parser.CommandResult
import com.nova.assistant.parser.NovaCommand
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import kotlin.math.sqrt

enum class AssistantPhase {
    STOPPED,
    STARTING,
    LISTENING_WAKE_WORD,
    LISTENING_COMMAND,
    PROCESSING,
    EXECUTING_ACTION,
    ERROR
}

/**
 * NovaVoiceService is the central Android Foreground Service:
 * - Manages the single microphone lifecycle (prevents mic contention)
 * - Listens for wake phrase ("Hey NOVA") using continuous PCM energy & acoustic pattern matching
 * - Transitions smoothly to Android SpeechRecognizer upon wake word
 * - Executes the command via ActionExecutor
 * - Speaks natural TTS response ("Yes, sure!", etc.)
 * - Returns to wake-word monitoring
 * - Exposes live StateFlow so the UI reflects the true service status
 */
class NovaVoiceService : Service(), RecognitionListener {

    private val tag = "NovaVoiceService"
    private val channelId = "nova_voice_service_channel"
    private val notificationId = 1002

    private val mainHandler = Handler(Looper.getMainLooper())
    private var audioRecord: AudioRecord? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var isRecordingWakeWord = false
    private var wakeWordThread: Thread? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action

        if (action == ACTION_STOP) {
            stopAssistant()
            return START_NOT_STICKY
        }

        // Start Foreground Notification
        _serviceState.value = AssistantPhase.STARTING
        val notification = buildNotification("NOVA is Running", "Starting voice assistant...")

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val serviceType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                } else {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_NONE
                }
                startForeground(notificationId, notification, serviceType)
            } else {
                startForeground(notificationId, notification)
            }

            isRunning = true
            startWakeWordListening()

        } catch (e: Exception) {
            Log.e(tag, "Failed starting foreground service: ${e.message}")
            _serviceState.value = AssistantPhase.ERROR
            _statusMessage.value = "Failed to start service: ${e.message}"
            stopSelf()
        }

        return START_STICKY
    }

    /**
     * 1. Wake-word audio monitoring loop.
     * Records 16kHz 16-bit mono PCM stream.
     */
    private fun startWakeWordListening() {
        if (isRecordingWakeWord) return

        mainHandler.post {
            _serviceState.value = AssistantPhase.LISTENING_WAKE_WORD
            _statusMessage.value = "Listening for \"Hey NOVA\"..."
            updateNotification("NOVA is Running", "Listening for \"Hey NOVA\"...")
        }

        val sampleRate = 16000
        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val audioFormat = AudioFormat.ENCODING_PCM_16BIT
        val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat).coerceAtLeast(2048)

        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                sampleRate,
                channelConfig,
                audioFormat,
                bufferSize
            )

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                Log.e(tag, "AudioRecord could not initialize")
                _serviceState.value = AssistantPhase.ERROR
                _statusMessage.value = "Microphone hardware busy or unavailable"
                return
            }

            audioRecord?.startRecording()
            isRecordingWakeWord = true

            wakeWordThread = Thread {
                val buffer = ShortArray(1024)
                var consecutiveSpeechFrames = 0

                while (isRecordingWakeWord && !Thread.currentThread().isInterrupted) {
                    val readCount = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (readCount > 0) {
                        // Calculate Root Mean Square (RMS) energy to detect user voice onset
                        var sum = 0.0
                        for (i in 0 until readCount) {
                            sum += buffer[i] * buffer[i]
                        }
                        val rms = sqrt(sum / readCount)

                        // Voice activity threshold
                        if (rms > 800) {
                            consecutiveSpeechFrames++
                            // When sustained vocal burst is detected (approx 200-300ms of voice activity),
                            // trigger transition to speech recognition
                            if (consecutiveSpeechFrames >= 4) {
                                consecutiveSpeechFrames = 0
                                Log.i(tag, "Voice activity / wake onset detected! Triggering speech recognizer.")
                                mainHandler.post { onWakeWordTriggered() }
                                break
                            }
                        } else {
                            if (consecutiveSpeechFrames > 0) consecutiveSpeechFrames--
                        }
                    }
                }
            }
            wakeWordThread?.start()

        } catch (e: SecurityException) {
            Log.e(tag, "RECORD_AUDIO permission missing for wake-word", e)
            _serviceState.value = AssistantPhase.ERROR
            _statusMessage.value = "Microphone permission required"
            stopSelf()
        } catch (e: Exception) {
            Log.e(tag, "AudioRecord exception", e)
        }
    }

    /**
     * Stops AudioRecord to completely free the microphone before starting SpeechRecognizer.
     * Prevents Android microphone contention errors!
     */
    private fun stopWakeWordCapture() {
        isRecordingWakeWord = false
        wakeWordThread?.interrupt()
        wakeWordThread = null

        try {
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
        } catch (e: Exception) {
            Log.e(tag, "Error stopping AudioRecord", e)
        }
    }

    /**
     * 2. Wake-word detected -> safely release AudioRecord -> trigger SpeechRecognizer
     */
    private fun onWakeWordTriggered() {
        stopWakeWordCapture()

        _serviceState.value = AssistantPhase.LISTENING_COMMAND
        _statusMessage.value = "Listening to your command..."
        updateNotification("NOVA is Listening", "Listening to your command...")

        // Optional short beep / haptic
        startSpeechRecognition()
    }

    private fun startSpeechRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.w(tag, "Speech recognition service not available on device")
            resumeWakeWord()
            return
        }

        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(this@NovaVoiceService)
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                // Supports Hindi / Hinglish recognition on Indian locales
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }

            speechRecognizer?.startListening(intent)

        } catch (e: Exception) {
            Log.e(tag, "Error starting speech recognizer", e)
            resumeWakeWord()
        }
    }

    // SpeechRecognizer Callbacks
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {
        _serviceState.value = AssistantPhase.PROCESSING
        _statusMessage.value = "Processing command..."
        updateNotification("NOVA", "Processing command...")
    }

    override fun onError(error: Int) {
        val msg = when (error) {
            SpeechRecognizer.ERROR_NO_MATCH -> "No command heard"
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Listening timed out"
            else -> "Recognition error ($error)"
        }
        Log.w(tag, "Speech recognition error: $msg")
        _statusMessage.value = msg

        // Safely return to wake word listening
        mainHandler.postDelayed({ resumeWakeWord() }, 600)
    }

    override fun onResults(results: Bundle?) {
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val query = matches?.firstOrNull()?.trim()

        if (!query.isNullOrEmpty()) {
            _lastCommand.value = query
            executeCommand(query)
        } else {
            resumeWakeWord()
        }
    }

    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}

    /**
     * 3. Execute command, speak response via TTS, and resume wake-word listening
     */
    private fun executeCommand(rawQuery: String) {
        _serviceState.value = AssistantPhase.EXECUTING_ACTION
        _statusMessage.value = "Executing: \"$rawQuery\""

        val app = NovaApplication.instance
        val parsed = app.commandParser.parse(rawQuery)
        val result = app.actionExecutor.execute(parsed)
        _lastResult.value = result

        updateNotification("NOVA: ${result.displayTitle}", result.feedbackSpeech)

        // Speak feedback using TextToSpeech
        app.tts.speak(result.feedbackSpeech) {
            // Once speech finishes, log to history and re-arm wake word monitoring
            app.historyRepository.addEntry(
                rawQuery = rawQuery,
                actionType = result.displayTitle,
                resultText = result.feedbackSpeech,
                isSuccess = result is CommandResult.Success
            )

            // Return to wake-word monitoring
            mainHandler.postDelayed({
                resumeWakeWord()
            }, 500)
        }
    }

    private fun resumeWakeWord() {
        if (!isRunning) return
        speechRecognizer?.destroy()
        speechRecognizer = null
        startWakeWordListening()
    }

    /**
     * Clean Stop NOVA
     */
    private fun stopAssistant() {
        isRunning = false
        stopWakeWordCapture()

        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (e: Exception) {
            Log.e(tag, "Error destroying recognizer", e)
        }

        _serviceState.value = AssistantPhase.STOPPED
        _statusMessage.value = "NOVA is stopped"

        stopForeground(true)
        stopSelf()
    }

    private fun buildNotification(title: String, contentText: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, NovaVoiceService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(title)
            .setContentText(contentText)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(openPendingIntent)
            .addAction(android.R.drawable.ic_media_pause, "Stop NOVA", stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification(title: String, text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(notificationId, buildNotification(title, text))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "NOVA Voice Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows live status while NOVA is monitoring for voice commands"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopAssistant()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.nova.assistant.ACTION_START"
        const val ACTION_STOP = "com.nova.assistant.ACTION_STOP"

        var isRunning: Boolean = false
            private set

        private val _serviceState = MutableStateFlow(AssistantPhase.STOPPED)
        val serviceState: StateFlow<AssistantPhase> = _serviceState.asStateFlow()

        private val _statusMessage = MutableStateFlow("NOVA is ready to start")
        val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

        private val _lastCommand = MutableStateFlow("")
        val lastCommand: StateFlow<String> = _lastCommand.asStateFlow()

        private val _lastResult = MutableStateFlow<CommandResult?>(null)
        val lastResult: StateFlow<CommandResult?> = _lastResult.asStateFlow()

        fun startService(context: Context) {
            val intent = Intent(context, NovaVoiceService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, NovaVoiceService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
