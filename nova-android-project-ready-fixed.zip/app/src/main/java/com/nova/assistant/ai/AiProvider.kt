package com.nova.assistant.ai

/**
 * Modular AI Provider Interface.
 *
 * Security Guidelines:
 * 1. NEVER embed private API keys in BuildConfig or strings.xml—APKs can be decompiled in seconds.
 * 2. User-provided keys are encrypted in Android Keystore / EncryptedSharedPreferences.
 * 3. In enterprise/production architectures, requests route through a verified backend proxy.
 */
interface AiProvider {
    val providerName: String
    val isConfigured: Boolean

    suspend fun generateActionPlan(userPrompt: String): Result<String>
}
