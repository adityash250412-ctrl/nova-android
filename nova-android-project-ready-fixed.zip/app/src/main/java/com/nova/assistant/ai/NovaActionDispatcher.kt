package com.nova.assistant.ai

import com.nova.assistant.parser.NovaCommand
import com.nova.assistant.parser.SettingTarget
import org.json.JSONObject

/**
 * NovaActionDispatcher enforces a STRICT ALLOWLIST on all AI outputs.
 * Prevents execution of arbitrary code, shell commands, or unvetted actions.
 */
class NovaActionDispatcher {

    private val allowedActions = setOf(
        "TOGGLE_FLASHLIGHT",
        "OPEN_APP",
        "OPEN_SETTINGS",
        "GET_BATTERY_STATUS",
        "CONVERSE"
    )

    fun validateAndMap(requestJson: String): Result<NovaCommand> {
        return try {
            val json = JSONObject(requestJson)
            val action = json.optString("actionType", "CONVERSE").uppercase()

            if (!allowedActions.contains(action)) {
                return Result.failure(
                    SecurityException("Blocked unauthorized AI action '$action'. Only allowlisted actions are permitted.")
                )
            }

            val command = when (action) {
                "TOGGLE_FLASHLIGHT" -> {
                    val desired = if (json.has("state")) json.getBoolean("state") else null
                    NovaCommand.ToggleFlashlight(desired)
                }
                "OPEN_APP" -> {
                    val appName = json.optString("appName", "").trim()
                    if (appName.isEmpty()) {
                        return Result.failure(IllegalArgumentException("Missing appName for OPEN_APP"))
                    }
                    NovaCommand.OpenApp(appName)
                }
                "OPEN_SETTINGS" -> {
                    val target = when (json.optString("target", "general").lowercase()) {
                        "wifi" -> SettingTarget.Wifi
                        "bluetooth" -> SettingTarget.Bluetooth
                        "display" -> SettingTarget.Display
                        "sound" -> SettingTarget.Sound
                        "battery" -> SettingTarget.Battery
                        "accessibility" -> SettingTarget.Accessibility
                        else -> SettingTarget.General
                    }
                    NovaCommand.OpenSettings(target)
                }
                "GET_BATTERY_STATUS" -> NovaCommand.SystemStatus("battery")
                "CONVERSE" -> NovaCommand.QueryAi(json.optString("speechResponse", "How can I help you?"))
                else -> NovaCommand.Unknown(requestJson)
            }

            Result.success(command)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
