package com.nova.assistant.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.assistant.parser.CommandResult
import com.nova.assistant.service.AssistantPhase
import com.nova.assistant.ui.theme.NovaBorder
import com.nova.assistant.ui.theme.NovaCyan
import com.nova.assistant.ui.theme.NovaDeepNavy
import com.nova.assistant.ui.theme.NovaErrorRed
import com.nova.assistant.ui.theme.NovaNeonBlue
import com.nova.assistant.ui.theme.NovaPurple
import com.nova.assistant.ui.theme.NovaSuccessGreen
import com.nova.assistant.ui.theme.NovaSurfaceDark
import com.nova.assistant.ui.theme.NovaSurfaceLight
import com.nova.assistant.ui.theme.NovaTextPrimary
import com.nova.assistant.ui.theme.NovaTextSecondary

@Composable
fun HomeScreen(
    isServiceRunning: Boolean,
    phase: AssistantPhase,
    statusExplanation: String,
    hasMicPermission: Boolean,
    lastCommand: String,
    lastResult: CommandResult?,
    onStartNova: () -> Unit,
    onStopNova: () -> Unit,
    onRequestMicPermission: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val isActivelyListening = phase == AssistantPhase.LISTENING_WAKE_WORD || phase == AssistantPhase.LISTENING_COMMAND

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = if (isActivelyListening) 0.96f else 1.0f,
        targetValue = if (isActivelyListening) 1.15f else 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isActivelyListening) 750 else 2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaDeepNavy)
            .padding(horizontal = 24.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // 1. Top Header: App Name & Status Indicator
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "NOVA",
                fontSize = 32.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 3.sp,
                color = NovaTextPrimary
            )
            Text(
                text = "PERSONAL VOICE ASSISTANT",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                color = NovaCyan
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Service Running Status Pill
            val (pillText, pillBg, pillBorder, pillColor) = when {
                !hasMicPermission -> Quad("MIC PERMISSION NEEDED", NovaErrorRed.copy(alpha = 0.15f), NovaErrorRed, NovaErrorRed)
                isServiceRunning -> Quad("NOVA IS RUNNING", NovaSuccessGreen.copy(alpha = 0.15f), NovaSuccessGreen, NovaSuccessGreen)
                else -> Quad("STOPPED", NovaSurfaceLight, NovaBorder, NovaTextSecondary)
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(pillBg)
                    .border(1.dp, pillBorder.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(pillColor)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = pillText,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = pillColor
                    )
                }
            }
        }

        // 2. Center: Large Interactive Control Button & Status Explanation
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Animated Voice Orb Button
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(210.dp)
                    .scale(if (isServiceRunning) pulseScale else 1.0f)
            ) {
                // Background Glow Ring
                if (isServiceRunning) {
                    Box(
                        modifier = Modifier
                            .size(200.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(
                                        if (isActivelyListening) NovaCyan.copy(alpha = 0.45f) else NovaPurple.copy(alpha = 0.25f),
                                        Color.Transparent
                                    )
                                )
                            )
                    )
                }

                // Core Main Button
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(140.dp)
                        .clip(CircleShape)
                        .background(
                            if (isServiceRunning) {
                                Brush.linearGradient(listOf(NovaCyan, NovaNeonBlue))
                            } else {
                                Brush.linearGradient(listOf(NovaSurfaceDark, NovaSurfaceLight))
                            }
                        )
                        .border(
                            2.dp,
                            if (isServiceRunning) NovaCyan else NovaBorder,
                            CircleShape
                        )
                        .clickable {
                            if (!hasMicPermission) {
                                onRequestMicPermission()
                            } else if (isServiceRunning) {
                                onStopNova()
                            } else {
                                onStartNova()
                            }
                        }
                ) {
                    Icon(
                        imageVector = if (isServiceRunning) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = if (isServiceRunning) "Stop NOVA" else "Start NOVA",
                        tint = if (isServiceRunning) NovaDeepNavy else NovaCyan,
                        modifier = Modifier.size(56.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Action Button
            if (!isServiceRunning) {
                Button(
                    onClick = {
                        if (!hasMicPermission) onRequestMicPermission() else onStartNova()
                    },
                    modifier = Modifier
                        .fillMaxWidth(0.8f)
                        .height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NovaCyan)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = NovaDeepNavy)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "START NOVA",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.5.sp,
                        color = NovaDeepNavy
                    )
                }
            } else {
                Button(
                    onClick = onStopNova,
                    modifier = Modifier
                        .fillMaxWidth(0.8f)
                        .height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NovaErrorRed)
                ) {
                    Icon(Icons.Default.Stop, contentDescription = null, tint = NovaTextPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "STOP NOVA",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.5.sp,
                        color = NovaTextPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Explanation of what NOVA is doing
            Text(
                text = statusExplanation,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                color = if (isServiceRunning) NovaCyan else NovaTextSecondary,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }

        // 3. Bottom: Recent Command & Result Area + Permission Link
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Recent Command Card
            if (lastCommand.isNotEmpty() || lastResult != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(NovaSurfaceDark)
                        .border(1.dp, NovaBorder, RoundedCornerShape(14.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "RECENT COMMAND",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = NovaCyan
                            )
                            if (lastResult != null) {
                                Icon(
                                    imageVector = if (lastResult is CommandResult.Success) Icons.Default.CheckCircle else Icons.Default.Error,
                                    contentDescription = null,
                                    tint = if (lastResult is CommandResult.Success) NovaSuccessGreen else NovaErrorRed,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        if (lastCommand.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "\"$lastCommand\"",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = NovaTextPrimary
                            )
                        }

                        if (lastResult != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = lastResult.feedbackSpeech,
                                fontSize = 12.sp,
                                color = NovaTextSecondary
                            )
                        }
                    }
                }
            } else {
                // Friendly beginner tip
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(NovaSurfaceDark)
                        .border(1.dp, NovaBorder, RoundedCornerShape(14.dp))
                        .padding(14.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "Say \"Hey NOVA, open YouTube\" or \"YouTube kholo\"",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = NovaTextSecondary,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Supports flashlight, calls, search, volume & apps in English & Hindi",
                            fontSize = 10.sp,
                            color = NovaCyan,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Microphone permission helper link
            if (!hasMicPermission) {
                Text(
                    text = "Microphone access is required. Tap to grant permission.",
                    fontSize = 11.sp,
                    color = NovaErrorRed,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .clickable { onRequestMicPermission() }
                        .padding(vertical = 4.dp)
                )
            } else {
                Text(
                    text = "Leave app anytime after starting • Say \"Hey NOVA\"",
                    fontSize = 11.sp,
                    color = NovaTextSecondary,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
