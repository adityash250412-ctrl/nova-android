package com.nova.assistant.actions

import android.content.Context
import android.media.AudioManager
import com.nova.assistant.parser.VolumeDirection

class VolumeController(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    fun adjustVolume(direction: VolumeDirection): Result<String> {
        val am = audioManager ?: return Result.failure(IllegalStateException("Audio service unavailable"))

        return try {
            when (direction) {
                VolumeDirection.UP -> {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                    Result.success("Volume increased")
                }
                VolumeDirection.DOWN -> {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                    Result.success("Volume decreased")
                }
                VolumeDirection.MUTE -> {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                    Result.success("Muted media volume")
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
