package com.nova.assistant.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * GeminiProvider implements real REST API calls to Google's Gemini models
 * (e.g., gemini-2.5-flash) using HttpURLConnection to keep the base build free
 * and zero-dependency.
 *
 * Security Reminder:
 * Never hardcode API keys in source files or BuildConfig. The apiKey must be
 * passed at runtime from user settings or Android Keystore.
 */
class GeminiProvider(
    private var apiKey: String = ""
) : AiProvider {

    override val providerName: String = "Google Gemini"
    override val isConfigured: Boolean
        get() = apiKey.isNotBlank()

    fun updateApiKey(key: String) {
        this.apiKey = key.trim()
    }

    override suspend fun generateActionPlan(userPrompt: String): Result<String> {
        if (!isConfigured) {
            return Result.failure(IllegalStateException("Gemini API key is not configured."))
        }

        return withContext(Dispatchers.IO) {
            try {
                val endpointUrl = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey")
                val connection = endpointUrl.openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.setRequestProperty("Content-Type", "application/json")
                connection.doOutput = true
                connection.connectTimeout = 10000
                connection.readTimeout = 10000

                val systemPrompt = """
                    You are NOVA Voice Assistant controlling an Android smartphone.
                    Interpret the user's intent and respond with a strictly formatted JSON object:
                    {
                      "actionType": "TOGGLE_FLASHLIGHT" | "OPEN_APP" | "OPEN_SETTINGS" | "GET_BATTERY_STATUS" | "CONVERSE",
                      "appName": "string (optional)",
                      "state": boolean (optional),
                      "target": "wifi" | "bluetooth" | "display" | "sound" | "battery" | "general" (optional),
                      "speechResponse": "Natural spoken response"
                    }
                    Respond with RAW JSON ONLY. No markdown formatting.
                """.trimIndent()

                val requestBody = JSONObject().apply {
                    put("contents", JSONArray().apply {
                        put(JSONObject().apply {
                            put("role", "user")
                            put("parts", JSONArray().apply {
                                put(JSONObject().put("text", "$systemPrompt\n\nUser: $userPrompt"))
                            })
                        })
                    })
                }

                OutputStreamWriter(connection.outputStream).use { writer ->
                    writer.write(requestBody.toString())
                    writer.flush()
                }

                val responseCode = connection.responseCode
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val responseText = BufferedReader(InputStreamReader(connection.inputStream)).use { it.readText() }
                    val jsonResponse = JSONObject(responseText)
                    val candidates = jsonResponse.optJSONArray("candidates")
                    val content = candidates?.optJSONObject(0)?.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    val rawGenerated = parts?.optJSONObject(0)?.optString("text") ?: ""

                    // Clean any markdown code fences if model enclosed it in ```json
                    val cleanedJson = rawGenerated.trim().removeSurrounding("```json", "```").removeSurrounding("```", "```").trim()
                    Result.success(cleanedJson)
                } else {
                    val errorText = BufferedReader(InputStreamReader(connection.errorStream ?: connection.inputStream)).use { it.readText() }
                    Result.failure(RuntimeException("Gemini API HTTP $responseCode: $errorText"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }
}
