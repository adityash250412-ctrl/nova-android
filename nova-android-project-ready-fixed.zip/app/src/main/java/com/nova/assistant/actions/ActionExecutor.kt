package com.nova.assistant.actions

import android.content.Context
import android.os.BatteryManager
import com.nova.assistant.accessibility.NovaAccessibilityService
import com.nova.assistant.parser.AccessibilityActionType
import com.nova.assistant.parser.CommandResult
import com.nova.assistant.parser.NovaCommand

class ActionExecutor(
    private val context: Context,
    private val flashlightController: FlashlightController,
    private val appLauncher: AppLauncher,
    private val settingsLauncher: SettingsLauncher,
    private val contactCaller: ContactCaller,
    private val searchLauncher: SearchLauncher,
    private val volumeController: VolumeController
) {

    fun execute(command: NovaCommand): CommandResult {
        return when (command) {
            is NovaCommand.OpenApp -> {
                val result = appLauncher.launchApp(command.appQuery)
                result.fold(
                    onSuccess = { msg ->
                        CommandResult.Success(
                            feedbackSpeech = "Yes, sure!",
                            displayTitle = "Opened ${command.appQuery.replaceFirstChar { it.uppercase() }}",
                            detail = msg
                        )
                    },
                    onFailure = { error ->
                        CommandResult.Failure(
                            feedbackSpeech = "Sorry, ${command.appQuery} is not installed on your phone.",
                            errorMessage = error.localizedMessage ?: "Application launch failed."
                        )
                    }
                )
            }

            is NovaCommand.ToggleFlashlight -> {
                if (!flashlightController.isSupported()) {
                    return CommandResult.Failure(
                        feedbackSpeech = "Flashlight hardware is not available on this phone.",
                        errorMessage = "No camera flash hardware detected."
                    )
                }

                val targetState = command.desiredState ?: !flashlightController.isTorchOn
                val result = flashlightController.setTorch(targetState)

                result.fold(
                    onSuccess = { enabled ->
                        val stateWord = if (enabled) "on" else "off"
                        CommandResult.Success(
                            feedbackSpeech = "Flashlight is $stateWord.",
                            displayTitle = "Flashlight ${stateWord.uppercase()}",
                            detail = "CameraManager.setTorchMode(cameraId, $enabled)"
                        )
                    },
                    onFailure = { error ->
                        CommandResult.Failure(
                            feedbackSpeech = "Could not change flashlight state.",
                            errorMessage = error.localizedMessage ?: "Unknown camera error."
                        )
                    }
                )
            }

            is NovaCommand.WebSearch -> {
                val result = searchLauncher.executeSearch(command.query, command.platform)
                result.fold(
                    onSuccess = { detail ->
                        CommandResult.Success(
                            feedbackSpeech = "Searching for ${command.query}.",
                            displayTitle = "Search: ${command.query}",
                            detail = detail
                        )
                    },
                    onFailure = { error ->
                        CommandResult.Failure(
                            feedbackSpeech = "Could not open search.",
                            errorMessage = error.localizedMessage ?: "Search intent failed."
                        )
                    }
                )
            }

            is NovaCommand.CallContact -> {
                val result = contactCaller.prepareCall(command.contactName)
                result.fold(
                    onSuccess = { (speech, detail) ->
                        CommandResult.Success(
                            feedbackSpeech = speech,
                            displayTitle = "Calling ${command.contactName}",
                            detail = detail
                        )
                    },
                    onFailure = { error ->
                        CommandResult.Failure(
                            feedbackSpeech = "Unable to access contacts.",
                            errorMessage = error.localizedMessage ?: "Contact lookup error."
                        )
                    }
                )
            }

            is NovaCommand.AdjustVolume -> {
                val result = volumeController.adjustVolume(command.direction)
                result.fold(
                    onSuccess = { detail ->
                        CommandResult.Success(
                            feedbackSpeech = detail,
                            displayTitle = "Volume Adjusted",
                            detail = detail
                        )
                    },
                    onFailure = { error ->
                        CommandResult.Failure(
                            feedbackSpeech = "Could not adjust volume.",
                            errorMessage = error.localizedMessage ?: "Volume adjustment error."
                        )
                    }
                )
            }

            is NovaCommand.SendWhatsAppMessage -> {
                val result = appLauncher.launchApp("whatsapp")
                result.fold(
                    onSuccess = {
                        CommandResult.Success(
                            feedbackSpeech = "Opening WhatsApp.",
                            displayTitle = "WhatsApp",
                            detail = "Drafting message for ${command.recipient}"
                        )
                    },
                    onFailure = {
                        CommandResult.Failure(
                            feedbackSpeech = "WhatsApp is not installed on this device.",
                            errorMessage = "App not found"
                        )
                    }
                )
            }

            is NovaCommand.OpenSettings -> {
                val result = settingsLauncher.launchSettings(command.target)
                result.fold(
                    onSuccess = { detail ->
                        CommandResult.Success(
                            feedbackSpeech = "Opening ${command.target.nameKey} settings.",
                            displayTitle = "${command.target.nameKey.replaceFirstChar { it.uppercase() }} Settings",
                            detail = detail
                        )
                    },
                    onFailure = { error ->
                        CommandResult.Failure(
                            feedbackSpeech = "Could not open settings.",
                            errorMessage = error.localizedMessage ?: "Settings intent failed."
                        )
                    }
                )
            }

            is NovaCommand.SystemStatus -> {
                if (command.metric == "battery") {
                    val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
                    val level = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
                    if (level >= 0) {
                        CommandResult.Success(
                            feedbackSpeech = "Your battery is at $level percent.",
                            displayTitle = "Battery Level",
                            detail = "$level%"
                        )
                    } else {
                        CommandResult.Failure(
                            feedbackSpeech = "Unable to read battery status right now.",
                            errorMessage = "Battery manager returned invalid capacity."
                        )
                    }
                } else {
                    CommandResult.Failure(
                        feedbackSpeech = "Status for ${command.metric} is not monitored.",
                        errorMessage = "Unsupported status metric."
                    )
                }
            }

            is NovaCommand.AccessibilityAction -> {
                val service = NovaAccessibilityService.instance
                if (service == null) {
                    return CommandResult.Failure(
                        feedbackSpeech = "Accessibility automation is not enabled. Please enable NOVA in Accessibility settings.",
                        errorMessage = "NovaAccessibilityService is not connected"
                    )
                }

                when (command.type) {
                    AccessibilityActionType.SCROLL_DOWN -> {
                        val success = service.scrollActiveWindow(forward = true)
                        if (success) {
                            CommandResult.Success("Scrolled down.", "Scroll Down", "Accessibility scroll action performed")
                        } else {
                            CommandResult.Failure("Unable to scroll this screen.", "Scroll failed")
                        }
                    }
                    AccessibilityActionType.SCROLL_UP -> {
                        val success = service.scrollActiveWindow(forward = false)
                        if (success) {
                            CommandResult.Success("Scrolled up.", "Scroll Up", "Accessibility scroll action performed")
                        } else {
                            CommandResult.Failure("Unable to scroll this screen.", "Scroll failed")
                        }
                    }
                    AccessibilityActionType.GO_BACK -> {
                        service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
                        CommandResult.Success("Going back.", "Back Action", "GLOBAL_ACTION_BACK performed")
                    }
                    AccessibilityActionType.GO_HOME -> {
                        service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)
                        CommandResult.Success("Going to home screen.", "Home Action", "GLOBAL_ACTION_HOME performed")
                    }
                    AccessibilityActionType.TAP_ELEMENT -> {
                        val success = service.clickNodeWithText(command.parameter)
                        if (success) {
                            CommandResult.Success("Tapped ${command.parameter}.", "Tapped Element", "Clicked node: ${command.parameter}")
                        } else {
                            CommandResult.Failure("Could not find ${command.parameter} on screen.", "Element not found")
                        }
                    }
                    AccessibilityActionType.TYPE_TEXT -> {
                        val success = service.enterTextIntoFocusedField(command.parameter)
                        if (success) {
                            CommandResult.Success("Typed text.", "Entered Text", command.parameter)
                        } else {
                            CommandResult.Failure("No editable field focused.", "Typing failed")
                        }
                    }
                }
            }

            is NovaCommand.QueryAi -> {
                CommandResult.Success(
                    feedbackSpeech = "I received your question: ${command.question}. To enable deep answers, configure an AI key in Settings.",
                    displayTitle = "AI Query",
                    detail = command.question
                )
            }

            is NovaCommand.Unknown -> {
                CommandResult.Failure(
                    feedbackSpeech = "I didn't recognize that command. Try 'YouTube kholo', 'turn on flashlight', or 'call Mom'.",
                    errorMessage = "Unrecognized command: \"${command.rawInput}\""
                )
            }
        }
    }
}
